# How to Update Your Service Configuration

## 🍪 Adding or Removing Cookie Files

### Option 1: Use the Auto-Update Script (EASIEST)

1. Add your new cookie file(s) to the `realchatapp` folder:
   ```
   Example: facebook_cookies_account7.json
   ```

2. Run the update script:
   ```powershell
   .\update_service_cookies.ps1
   ```

3. The script will:
   - Automatically detect ALL cookie files
   - Stop the service
   - Reconfigure it with all found cookies
   - Restart the service

**That's it!** The service will now use all your cookie files.

### Option 2: Manual Update

If you prefer to do it manually:

```powershell
# 1. Stop the service
Stop-Service -Name FacebookMessengerBot

# 2. Remove the old service
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe remove FacebookMessengerBot confirm

# 3. Install with new cookie list (example with 5 accounts)
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe install FacebookMessengerBot "C:\Users\Administrator\AppData\Local\Programs\Python\Python312\python.exe" "C:\Users\Administrator\Downloads\realchatapp\messenger_playwright_multi.py" --cookies facebook_cookies.json facebook_cookies_account4.json facebook_cookies_account5.json facebook_cookies_account6.json facebook_cookies_account7.json --poll 10

# 4. Reconfigure settings
$nssm = "C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe"
& $nssm set FacebookMessengerBot AppDirectory "C:\Users\Administrator\Downloads\realchatapp"
& $nssm set FacebookMessengerBot Start SERVICE_AUTO_START
& $nssm set FacebookMessengerBot AppEnvironmentExtra "HEADLESS=true" "PLAYWRIGHT_BROWSERS_PATH=C:\Users\Administrator\AppData\Local\ms-playwright"
& $nssm set FacebookMessengerBot AppStdout "C:\Users\Administrator\Downloads\realchatapp\logs\service_output.log"
& $nssm set FacebookMessengerBot AppStderr "C:\Users\Administrator\Downloads\realchatapp\logs\service_error.log"
& $nssm set FacebookMessengerBot AppRestartDelay 15000

# 5. Start the service
Start-Service -Name FacebookMessengerBot
```

---

## 🔑 Changing API Keys or Environment Variables

### ✅ YES! Just change the `.env` file and restart the service

Your bot reads configuration from the `.env` file at startup. To update API keys:

1. **Edit the `.env` file:**
   ```powershell
   notepad .env
   ```

2. **Change your API keys:**
   ```env
   GEMINI_API_KEY=your_new_gemini_key_here
   GROQ_API_KEY=your_new_groq_key_here
   OPENROUTER_API_KEY=your_new_openrouter_key_here
   ```

3. **Save the file**

4. **Restart the service:**
   ```powershell
   Restart-Service -Name FacebookMessengerBot
   ```

**That's it!** The service will read the new API keys on startup.

---

## 🔄 Updating Bot Code (messenger_playwright_multi.py)

### ✅ YES! Just update the file and restart the service

1. **Update your `messenger_playwright_multi.py` file**
   - Edit the file directly
   - Or replace it with a new version

2. **Restart the service:**
   ```powershell
   Restart-Service -Name FacebookMessengerBot
   ```

**That's it!** The service will run the updated code.

---

## ⚙️ Changing Other Settings

### Changing Poll Interval

To change from `--poll 10` to a different value:

1. Run the update script:
   ```powershell
   .\update_service_cookies.ps1
   ```
   
2. Before it runs, edit the script and change line 31:
   ```powershell
   $FullArgs = "`"$ScriptPath`" --cookies $CookieArgs --poll 15"  # Change to 15 or any value
   ```

Or manually update the service (see Option 2 above).

### Changing from Headless to Visible

If you want to see the browser windows:

```powershell
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe set FacebookMessengerBot AppEnvironmentExtra "HEADLESS=false" "PLAYWRIGHT_BROWSERS_PATH=C:\Users\Administrator\AppData\Local\ms-playwright"
Restart-Service -Name FacebookMessengerBot
```

---

## 📋 What Requires Service Restart vs Just File Update

| Change | Requires Service Restart? | Requires Service Reconfiguration? |
|--------|---------------------------|-----------------------------------|
| Adding/Removing cookie files | ✅ YES | ✅ YES (use update script) |
| Changing API keys in `.env` | ✅ YES (restart only) | ❌ NO |
| Updating bot code | ✅ YES (restart only) | ❌ NO |
| Changing `--poll` value | ✅ YES | ✅ YES (use update script) |
| Changing HEADLESS mode | ✅ YES | ✅ YES (NSSM command) |
| Updating cookie file contents | ✅ YES (restart only) | ❌ NO |

---

## 🚀 Quick Reference Commands

### Restart service (for code/API/cookie content changes)
```powershell
Restart-Service -Name FacebookMessengerBot
```

### Update cookie files (for adding/removing accounts)
```powershell
.\update_service_cookies.ps1
```

### Check service status
```powershell
Get-Service -Name FacebookMessengerBot
```

### View logs
```powershell
Get-Content logs\service_error.log -Tail 20
```

---

## 📝 Example Workflows

### Adding a New Account (account7)

1. Export cookies for account7 → save as `facebook_cookies_account7.json`
2. Put the file in your `realchatapp` folder
3. Run: `.\update_service_cookies.ps1`
4. Type `yes` when prompted
5. Done! Service now runs with 5 accounts

### Updating Your Gemini API Key

1. Edit `.env`: `notepad .env`
2. Change `GEMINI_API_KEY=new_key_here`
3. Save and close
4. Run: `Restart-Service -Name FacebookMessengerBot`
5. Done! New API key is active

### Updating Bot Code

1. Edit `messenger_playwright_multi.py` or replace it
2. Run: `Restart-Service -Name FacebookMessengerBot`
3. Done! Service runs the new code

### Changing Poll Speed to 5 Seconds

1. Edit `update_service_cookies.ps1`
2. Find line 31, change `--poll 10` to `--poll 5`
3. Run: `.\update_service_cookies.ps1`
4. Type `yes` when prompted
5. Done! Service now polls every 5 seconds

---

## ⚠️ Important Notes

1. **Cookie file contents**: If you just update the contents of existing cookie files (not add/remove), you only need to restart the service, not reconfigure it.

2. **The service reads from the folder**: Any changes you make to `.env`, Python code, or cookie file contents will be picked up when the service restarts.

3. **Adding/removing files**: Only when you ADD or REMOVE cookie files do you need to reconfigure the service (use the update script).

4. **Batch file still works**: You can still test changes with `FORCE_RESTART_HIDDEN.bat` before applying them to the service. Just stop the service first:
   ```powershell
   Stop-Service -Name FacebookMessengerBot
   # Run your batch file to test
   # When happy, start service again
   Start-Service -Name FacebookMessengerBot
   ```

---

## 🎯 Summary

**For most changes (API keys, code updates, cookie content):**
- ✅ Just edit the file
- ✅ Restart the service
- ✅ Done!

**For adding/removing cookie files:**
- ✅ Add the new cookie file(s)
- ✅ Run `.\update_service_cookies.ps1`
- ✅ Done!

The service always reads from your folder, so changes to files are always effective after a restart!
