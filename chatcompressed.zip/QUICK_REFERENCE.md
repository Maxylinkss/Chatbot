# Quick Reference Card

## 📋 Common Tasks

### ✅ YES, you can just change files in the folder!

| What You Want to Change | What to Do |
|------------------------|------------|
| **API Keys** (Gemini, Groq, etc.) | Edit `.env` → Restart service |
| **Bot Code** | Edit `messenger_playwright_multi.py` → Restart service |
| **Cookie Contents** (re-export) | Replace cookie JSON file → Restart service |
| **Add/Remove Accounts** | Add/remove cookie files → Run update script |

---

## 🚀 Essential Commands

```powershell
# Restart service (after changing API keys, code, or cookie contents)
Restart-Service -Name FacebookMessengerBot

# Update with new cookie files (after adding/removing accounts)
.\update_service_cookies.ps1

# Check status
Get-Service -Name FacebookMessengerBot

# View live logs
Get-Content logs\service_error.log -Wait -Tail 20

# Interactive management menu
.\manage_service.ps1
```

---

## 🔄 Two Types of Updates

### Type 1: Simple Changes (Just Restart) ⚡
**No service reconfiguration needed**

- Changing API keys in `.env`
- Updating bot code
- Replacing cookie file contents
- Any changes to existing files

**How to apply:**
```powershell
# 1. Make your changes to the files
# 2. Restart the service
Restart-Service -Name FacebookMessengerBot
```

### Type 2: Structure Changes (Reconfigure) 🔧
**Service needs to know about new/removed files**

- Adding new cookie files (new accounts)
- Removing cookie files
- Changing number of accounts

**How to apply:**
```powershell
# 1. Add/remove cookie files
# 2. Run update script
.\update_service_cookies.ps1
```

---

## 📝 Step-by-Step Examples

### Change Gemini API Key
```powershell
notepad .env                            # Edit API key
Restart-Service -Name FacebookMessengerBot  # Apply changes
```

### Add a 5th Account
```powershell
# 1. Export cookies, save as facebook_cookies_account7.json
# 2. Put file in realchatapp folder
.\update_service_cookies.ps1            # Detect and apply
```

### Update Bot Code
```powershell
notepad messenger_playwright_multi.py   # Make changes
Restart-Service -Name FacebookMessengerBot  # Apply changes
```

### Replace Cookie File (Re-export)
```powershell
# 1. Export new cookies, overwrite old file
Restart-Service -Name FacebookMessengerBot  # Apply changes
```

---

## 🎯 The Golden Rule

**The service always reads from your folder!**

1. Make changes to files in `C:\Users\Administrator\Downloads\realchatapp\`
2. Restart the service (or run update script if adding/removing files)
3. Done! Changes are active

---

## 📊 Quick Decision Tree

```
Did you add or remove cookie files?
├─ YES → Run: .\update_service_cookies.ps1
└─ NO  → Just restart service
          └─ Restart-Service -Name FacebookMessengerBot
```

---

## 🔍 Checking What's Running

```powershell
# See exact command line
Get-CimInstance Win32_Process | Where-Object {$_.Name -eq "python.exe"} | Select-Object CommandLine

# Check service status
Get-Service -Name FacebookMessengerBot

# View recent activity
Get-Content logs\service_error.log -Tail 20
```

---

## ⚠️ Remember

- ✅ Service reads from folder → Changes to files ARE effective after restart
- ✅ Only adding/removing files needs reconfiguration
- ✅ Batch file still works for testing (stop service first)
- ✅ Service keeps running when you log off

---

## 📚 More Info

- **Full guide:** `HOW_TO_UPDATE_SERVICE.md`
- **Service details:** `SERVICE_README.md`
- **Management script:** `manage_service.ps1`
