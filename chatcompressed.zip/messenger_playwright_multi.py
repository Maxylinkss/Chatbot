import os
import re
import json
import glob
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional
from dotenv import load_dotenv
import pytz

from playwright.async_api import async_playwright, Browser, BrowserContext, Page, TimeoutError as PlaywrightTimeoutError
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
import requests
from PIL import Image

# ======================
# 🔑 CONFIG / ENV
# ======================
# Load environment variables from .env file
load_dotenv()

# Multiple AI provider support
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")  # Free alternative
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")  # Free alternative

HEADLESS = os.getenv("HEADLESS", "true").lower() in ("1", "true", "yes")
MESSENGER_URL = os.getenv("MESSENGER_URL", "https://www.facebook.com/messages")
POLL_INTERVAL_SECONDS = float(os.getenv("POLL_INTERVAL_SECONDS", "3.0"))
SEND_TYPING_DELAY = float(os.getenv("SEND_TYPING_DELAY", "0.08"))
LOG_DIR = os.getenv("LOG_DIR", "logs")

# Configure Gemini if available
GEMINI_MODEL = None
if GEMINI_API_KEY and GEMINI_AVAILABLE:
    try:
        genai.configure(api_key=GEMINI_API_KEY)
        # Try to use the model, with fallback to stable model names
        # Prioritize latest vision models since we need image analysis
        model_variants = [
            "gemini-2.0-flash-exp",  # Latest with best vision capabilities
            "gemini-1.5-flash",  # Stable fallback
            "gemini-1.5-flash-latest",
            GEMINI_MODEL_NAME,
            "gemini-1.5-pro-latest",
            "gemini-1.5-pro",
            "gemini-pro-vision"
        ]
        
        for model_name in model_variants:
            try:
                GEMINI_MODEL = genai.GenerativeModel(model_name)
                print(f"[INIT] OK Gemini {model_name} configured successfully")
                break
            except Exception as model_err:
                print(f"[INIT] WARNING Gemini {model_name} not available: {model_err}")
                continue
        
        if not GEMINI_MODEL:
            print(f"[INIT] WARNING No Gemini models available - image analysis will use fallback")
    except Exception as e:
        print(f"[INIT] WARNING Gemini init failed: {e}")

# Track which providers have hit limits
PROVIDER_COOLDOWNS = {}

# ======================
# 🧰 LOGGING
# ======================

def make_logger(account_name: str) -> logging.Logger:
    os.makedirs(LOG_DIR, exist_ok=True)
    logger = logging.getLogger(f"fb.{account_name}")
    logger.setLevel(logging.INFO)

    # Avoid duplicate handlers if re-created
    if logger.handlers:
        return logger

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s] %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    fh = logging.FileHandler(Path(LOG_DIR) / f"messenger_{account_name}.log", encoding="utf-8")
    fh.setFormatter(fmt)

    logger.addHandler(sh)
    logger.addHandler(fh)
    return logger

# ======================
# 🍪 COOKIES
# ======================

SAMESITE_MAP = {
    "no_restriction": "None",
    "lax": "Lax",
    "strict": "Strict",
    "unspecified": None,
    None: None,
}

def normalize_cookies_for_playwright(raw: Any) -> List[Dict[str, Any]]:
    """Convert cookies exported for Selenium/Chrome to Playwright format.
    Accepts either a list of cookie dicts or an object with {"cookies": [...]}
    """
    if isinstance(raw, dict) and "cookies" in raw:
        raw_cookies = raw.get("cookies", [])
    elif isinstance(raw, list):
        raw_cookies = raw
    else:
        return []

    out = []
    for c in raw_cookies:
        name = c.get("name")
        value = c.get("value")
        if not name or value is None:
            continue
        domain = c.get("domain", ".facebook.com")
        path = c.get("path", "/")
        secure = bool(c.get("secure", True))
        http_only = bool(c.get("httpOnly", False))

        # expirationDate (float seconds) -> expires (int seconds)
        expires = None
        if "expirationDate" in c and c.get("session") is not True:
            try:
                expires = int(float(c.get("expirationDate")))
            except Exception:
                expires = None
        elif "expires" in c:
            try:
                expires = int(c.get("expires"))
            except Exception:
                expires = None

        same_site_raw = c.get("sameSite")
        same_site = SAMESITE_MAP.get(str(same_site_raw).lower(), None) if isinstance(same_site_raw, str) else SAMESITE_MAP.get(same_site_raw)

        pc: Dict[str, Any] = {
            "name": name,
            "value": value,
            "domain": domain,
            "path": path,
            "secure": secure,
            "httpOnly": http_only,
        }
        if same_site:
            pc["sameSite"] = same_site  # Playwright expects: "Lax" | "Strict" | "None"
        if expires is not None:
            pc["expires"] = expires

        out.append(pc)
    return out

async def load_cookies_into_context(context: BrowserContext, cookie_file: Path, logger: logging.Logger) -> bool:
    try:
        if not cookie_file.exists():
            logger.error(f"Cookie file not found: {cookie_file}")
            return False
        with open(cookie_file, "r", encoding="utf-8") as f:
            raw = json.load(f)
        cookies = normalize_cookies_for_playwright(raw)
        if not cookies:
            logger.error(f"No valid cookies in file: {cookie_file}")
            return False
        # Must set at least one url-domain relationship before add_cookies if needed
        await context.add_cookies(cookies)
        logger.info(f"Loaded {len(cookies)} cookies from {cookie_file.name}")
        return True
    except Exception as e:
        logger.error(f"Failed to load cookies: {e}")
        return False

# ======================
# 🤖 AI
# ======================

def get_available_images(img_folder: Path = None) -> List[Path]:
    """Get list of all available images from the img folder."""
    if img_folder is None:
        img_folder = Path(__file__).parent / "img"
    
    if not img_folder.exists():
        return []
    
    # Support common image formats
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.gif', '*.webp']
    images = []
    for ext in image_extensions:
        images.extend(img_folder.glob(ext))
        images.extend(img_folder.glob(ext.upper()))
    
    return sorted(images)

def load_image_analysis_cache(cache_file: str = "image_analysis_cache.json") -> Dict[str, Dict]:
    """Load cached image analysis results."""
    try:
        path = Path(cache_file)
        if not path.exists():
            return {}
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_image_analysis_cache(cache_data: Dict[str, Dict], cache_file: str = "image_analysis_cache.json"):
    """Save image analysis cache."""
    try:
        path = Path(cache_file)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cache_data, f, indent=2)
    except Exception as e:
        print(f"Error saving image analysis cache: {e}")

async def analyze_image_with_ai(image_path: Path, logger: logging.Logger) -> Dict[str, Any]:
    """Analyze an image using Gemini Vision to understand its content and context."""
    response_text = ""
    try:
        if not GEMINI_MODEL:
            logger.debug(f"Gemini model not available for {image_path.name}")
            return {"category": "unknown", "description": "AI not available", "is_uniform": False, "is_casual": True, "clothing_type": "casual wear", "setting": "unknown", "time_suitable": "any_time"}
        
        # Load and prepare image with error handling
        try:
            img = Image.open(image_path)
            # Verify image is valid
            img.verify()
            # Reopen after verify (PIL closes it)
            img = Image.open(image_path)
        except Exception as img_err:
            logger.error(f"Failed to load image {image_path.name}: {img_err}")
            return {"category": "unknown", "description": "Image load failed", "is_uniform": False, "is_casual": True, "clothing_type": "casual wear", "setting": "unknown", "time_suitable": "any_time"}
        
        # Create analysis prompt - more specific for military/casual detection
        prompt = """
You are analyzing a photo to categorize the clothing and setting. 
Look carefully at what the person is wearing and where they are.

Provide ONLY a JSON response with these exact fields:

{
  "is_uniform": true or false (true if wearing ANY kind of military uniform, army attire, camouflage, combat gear, or professional military clothing),
  "is_casual": true or false (true if wearing casual everyday clothes like t-shirt, jeans, regular shirt, casual dress, home clothes),
  "clothing_type": "military_uniform" or "casual_wear" or "formal" or "sportswear" or "home_wear" or "other",
  "setting": "military_base" or "outdoor" or "indoor" or "office" or "home" or "unknown",
  "time_suitable": "work_hours" or "off_hours" or "any_time",
  "has_camouflage": true or false (true if wearing camouflage pattern),
  "description": "detailed description of the clothing, colors, and setting"
}

IMPORTANT: 
- Look for camouflage patterns, military badges, combat boots, military caps
- If you see ANY military/army clothing, set is_uniform=true and clothing_type="military_uniform"
- If casual everyday clothes, set is_casual=true and clothing_type="casual_wear"
- Respond ONLY with valid JSON, no other text or markdown.
"""
        
        # Analyze with Gemini Vision with timeout
        try:
            response = await asyncio.wait_for(
                asyncio.to_thread(GEMINI_MODEL.generate_content, [prompt, img]),
                timeout=30.0  # 30 second timeout
            )
        except asyncio.TimeoutError:
            logger.warning(f"Gemini API timeout for {image_path.name}")
            return {"category": "unknown", "description": "API timeout", "is_uniform": False, "is_casual": True, "clothing_type": "casual wear", "setting": "unknown", "time_suitable": "any_time"}
        except Exception as api_err:
            logger.warning(f"Gemini API error for {image_path.name}: {type(api_err).__name__}: {str(api_err)[:100]}")
            return {"category": "unknown", "description": "API error", "is_uniform": False, "is_casual": True, "clothing_type": "casual wear", "setting": "unknown", "time_suitable": "any_time"}
        
        if not response:
            logger.warning(f"Empty response from Gemini for {image_path.name}")
            return {"category": "unknown", "description": "No response", "is_uniform": False, "is_casual": True, "clothing_type": "casual wear", "setting": "unknown", "time_suitable": "any_time"}
        
        # Get response text safely
        try:
            response_text = response.text.strip() if hasattr(response, 'text') and response.text else ""
        except Exception as text_err:
            logger.warning(f"Failed to extract response text for {image_path.name}: {text_err}")
            return {"category": "unknown", "description": "Text extraction failed", "is_uniform": False, "is_casual": True, "clothing_type": "casual wear", "setting": "unknown", "time_suitable": "any_time"}
        
        if not response_text:
            logger.warning(f"Empty response text from Gemini for {image_path.name}")
            return {"category": "unknown", "description": "Empty response", "is_uniform": False, "is_casual": True, "clothing_type": "casual wear", "setting": "unknown", "time_suitable": "any_time"}
        
        # Parse JSON response
        # Remove markdown code blocks if present
        if response_text.startswith("```"):
            # Split by triple backticks and get the content
            parts = response_text.split("```")
            if len(parts) >= 3:
                # Get the content between the first and second ```
                response_text = parts[1]
                # Remove 'json' prefix if present
                if response_text.strip().startswith("json"):
                    response_text = response_text.strip()[4:]
                response_text = response_text.strip()
        
        # Also try to extract JSON if it's wrapped in other text
        if "{" in response_text and "}" in response_text:
            start_idx = response_text.find("{")
            end_idx = response_text.rfind("}") + 1
            response_text = response_text[start_idx:end_idx]
        
        # Try to parse JSON
        try:
            analysis = json.loads(response_text)
            # Validate required fields
            required_fields = ["is_uniform", "is_casual", "clothing_type", "setting", "time_suitable", "has_camouflage", "description"]
            for field in required_fields:
                if field not in analysis:
                    logger.warning(f"Missing field '{field}' in analysis for {image_path.name}")
                    if field in ["clothing_type", "setting", "description"]:
                        analysis[field] = "unknown"
                    elif field == "is_uniform":
                        analysis[field] = False
                    elif field == "is_casual":
                        analysis[field] = True
                    elif field == "has_camouflage":
                        analysis[field] = False
                    else:
                        analysis[field] = "any_time"
            
            logger.info(f"✅ Image analysis for {image_path.name}: {analysis.get('clothing_type', 'unknown')} - {analysis.get('time_suitable', 'any')}")
            return analysis
        except json.JSONDecodeError as json_err:
            logger.warning(f"Failed to parse JSON response for {image_path.name}: {json_err}")
            logger.debug(f"Response text was: {response_text[:200]}")
            # Fallback: Try to determine from response text
            response_lower = response_text.lower()
            is_uniform = any(word in response_lower for word in ["uniform", "military", "army", "soldier", "formal", "professional"])
            return {
                "is_uniform": is_uniform,
                "is_casual": not is_uniform,
                "clothing_type": "military uniform" if is_uniform else "casual wear",
                "setting": "unknown",
                "time_suitable": "work_hours" if is_uniform else "off_hours",
                "description": response_text[:100] if response_text else "Unknown"
            }
        
    except Exception as e:
        logger.error(f"Unexpected error analyzing image {image_path.name}: {type(e).__name__}: {str(e)[:100]}")
        # Default: assume casual and return safe fallback
        return {
            "category": "unknown",
            "description": f"Error: {str(e)[:50]}",
            "is_uniform": False,
            "is_casual": True,
            "clothing_type": "casual wear",
            "setting": "unknown",
            "time_suitable": "any_time"
        }

async def analyze_all_images(logger: logging.Logger, account_name: str = "default") -> Dict[str, Dict]:
    """Analyze all images in img folder and cache results."""
    cache_file = f"image_analysis_cache_{account_name}.json"
    cache = load_image_analysis_cache(cache_file)
    
    images = get_available_images()
    if not images:
        logger.warning("No images found in img folder")
        return {}
    
    logger.info(f"Found {len(images)} images, checking which need analysis...")
    
    updated = False
    for img_path in images:
        img_name = img_path.name
        
        # Check if already analyzed and file hasn't changed
        if img_name in cache:
            cached_mtime = cache[img_name].get("modified_time", 0)
            current_mtime = img_path.stat().st_mtime
            
            if cached_mtime == current_mtime:
                logger.debug(f"Using cached analysis for {img_name}")
                continue
        
        # Analyze image
        logger.info(f"🔍 Analyzing {img_name} with AI vision...")
        analysis = await analyze_image_with_ai(img_path, logger)
        
        # Add metadata
        analysis["modified_time"] = img_path.stat().st_mtime
        analysis["file_name"] = img_name
        
        cache[img_name] = analysis
        updated = True
        
        # Small delay to avoid rate limits
        await asyncio.sleep(2)
    
    if updated:
        save_image_analysis_cache(cache, cache_file)
        logger.info(f"✅ Image analysis complete. Results cached.")
    
    return cache

def is_work_hours() -> bool:
    """Check if current time is during work/office hours in Syria timezone."""
    try:
        syria_tz = pytz.timezone('Asia/Damascus')
        syria_time = datetime.now(syria_tz)
        hour = syria_time.hour
        
        # Work hours: 8 AM to 5 PM (Monday-Friday)
        # Also check if it's a weekday
        is_weekday = syria_time.weekday() < 5  # Monday=0, Friday=4
        is_work_time = 8 <= hour < 17  # 8 AM to 5 PM
        
        return is_weekday and is_work_time
    except Exception:
        # Default to off-hours if we can't determine
        return False

def load_image_tracking(tracking_file: str = "image_tracking.json") -> Dict[str, List[str]]:
    """Load tracking data of which images have been sent to which conversations."""
    try:
        path = Path(tracking_file)
        if not path.exists():
            return {}
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_image_tracking(tracking_data: Dict[str, List[str]], tracking_file: str = "image_tracking.json"):
    """Save tracking data of which images have been sent to which conversations."""
    try:
        path = Path(tracking_file)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(tracking_data, f, indent=2)
    except Exception as e:
        print(f"Error saving image tracking: {e}")

async def get_next_image_for_conversation(
    convo_url: str, 
    tracking_data: Dict[str, List[str]], 
    image_analysis_cache: Dict[str, Dict],
    logger: logging.Logger,
    request_type: str = 'any'
) -> Optional[Path]:
    """Get the next contextually appropriate image to send based on time, AI analysis, and user request.
    
    Args:
        request_type: 'uniform', 'casual', or 'any' - what type of photo the person asked for
    """
    available_images = get_available_images()
    if not available_images:
        return None
    
    # Get list of images already sent to this conversation
    sent_images = tracking_data.get(convo_url, [])
    
    # Find images that haven't been sent yet
    unsent_images = [img for img in available_images if img.name not in sent_images]
    
    # If all images have been sent, reset and start over
    if not unsent_images:
        tracking_data[convo_url] = []
        unsent_images = available_images
    
    if not unsent_images:
        return None
    
    # Determine if it's work hours
    work_hours = is_work_hours()
    
    # Log what we're looking for
    if request_type == 'uniform':
        logger.info(f"Selecting UNIFORM/MILITARY image (user requested)...")
    elif request_type == 'casual':
        logger.info(f"Selecting CASUAL image (user requested)...")
    else:
        logger.info(f"Selecting image for {'WORK HOURS' if work_hours else 'OFF HOURS'}...")
    
    # Filter images based on context using AI analysis
    contextual_images = []
    fallback_images = []
    
    for img in unsent_images:
        analysis = image_analysis_cache.get(img.name, {})
        
        if not analysis:
            # No analysis available, add to fallback
            fallback_images.append(img)
            continue
        
        is_uniform = analysis.get("is_uniform", False)
        is_casual = analysis.get("is_casual", False)
        time_suitable = analysis.get("time_suitable", "any_time")
        clothing_type = analysis.get("clothing_type", "unknown")
        has_camouflage = analysis.get("has_camouflage", False)
        
        # PRIORITY 1: If user specifically requested a type, prioritize that
        if request_type == 'uniform':
            # User wants military/uniform photos
            if is_uniform or has_camouflage or clothing_type == "military_uniform":
                contextual_images.append((img, 10))  # HIGHEST priority
            elif time_suitable == "work_hours":
                contextual_images.append((img, 3))  # Medium priority
            else:
                fallback_images.append(img)  # Low priority
        elif request_type == 'casual':
            # User wants casual/home photos
            if is_casual or clothing_type in ["casual_wear", "home_wear"]:
                contextual_images.append((img, 10))  # HIGHEST priority
            elif time_suitable == "off_hours":
                contextual_images.append((img, 3))  # Medium priority
            else:
                fallback_images.append(img)  # Low priority
        # PRIORITY 2: No specific request - use work hours logic
        elif work_hours:
            # During work hours: prefer uniform/professional images
            if is_uniform or has_camouflage or time_suitable == "work_hours":
                contextual_images.append((img, 2))  # High priority
            elif time_suitable == "any_time":
                contextual_images.append((img, 1))  # Medium priority
            else:
                fallback_images.append(img)  # Low priority
        else:
            # Off hours: prefer casual images
            if is_casual or time_suitable == "off_hours":
                contextual_images.append((img, 2))  # High priority
            elif time_suitable == "any_time":
                contextual_images.append((img, 1))  # Medium priority
            else:
                fallback_images.append(img)  # Low priority
    
    # Sort by priority and select
    if contextual_images:
        contextual_images.sort(key=lambda x: x[1], reverse=True)  # Sort by priority
        selected = contextual_images[0][0]
        analysis = image_analysis_cache.get(selected.name, {})
        logger.info(f"✅ Selected '{selected.name}' - {analysis.get('clothing_type', 'unknown')} ({analysis.get('description', '')[:50]})")
        return selected
    elif fallback_images:
        selected = fallback_images[0]
        logger.info(f"⚠️ Using fallback image '{selected.name}' (no contextual match)")
        return selected
    else:
        # Last resort: return first unsent
        logger.warning(f"Using first unsent image (no analysis available)")
        return unsent_images[0] if unsent_images else None

def detect_image_request(message_text: str) -> dict:
    """Detect if the message is asking for a picture/photo/image and what type they want.
    Returns: {'is_request': bool, 'request_type': str, 'preference': str}
    """
    result = {
        'is_request': False,
        'request_type': 'any',  # 'uniform', 'casual', 'home', 'work', 'any'
        'preference': None
    }
    message_lower = message_text.lower().strip()
    
    # FIRST: Check for phrases that are NOT requests (questions/discussions about images)
    # These are people talking ABOUT pictures, not asking FOR them
    non_request_patterns = [
        # Questions about existing pictures
        'where did you take', 'where was this', 'where did u take', 'where was that',
        'when did you take', 'when was this', 'when did u take', 'when was that',
        'who took', 'who is in', 'who are', "who's in", "who's that",
        'what is that', 'what is this', 'what are you', 'what were you',
        'which one', 'which picture', 'which photo',
        'how did you', 'how old',
        
        # Reactions/comments about pictures
        'nice picture', 'nice photo', 'nice pic', 'beautiful picture', 'beautiful photo',
        'love the picture', 'love the photo', 'love this picture', 'love this photo',
        'great picture', 'great photo', 'cool picture', 'cool photo',
        'pretty picture', 'pretty photo', 'amazing picture', 'amazing photo',
        'wow', 'gorgeous', 'stunning', 'lovely',
        
        # Past tense (talking about pictures already sent)
        'the picture you', 'the photo you', 'that picture', 'that photo', 'this picture', 'this photo',
        'your last picture', 'your last photo', 'the last picture', 'the last photo',
        'in the picture', 'in the photo', 'in that pic',
        
        # Spanish
        'donde tomaste', 'cuando tomaste', 'quien es', 'que bonita foto', 'linda foto',
        'hermosa foto', 'la foto que', 'esa foto',
        
        # French
        'où as-tu pris', 'quand as-tu pris', 'qui est', 'belle photo', 'jolie photo',
        'la photo que', 'cette photo',
        
        # Portuguese
        'onde você tirou', 'quando você tirou', 'quem é', 'linda foto', 'bonita foto',
        'a foto que', 'essa foto'
    ]
    
    # If the message matches a non-request pattern, it's NOT a request
    if any(pattern in message_lower for pattern in non_request_patterns):
        return result
    
    # SECOND: Check for actual REQUEST patterns (action verbs + image words)
    # These are people actually ASKING for pictures
    request_patterns = [
        # Direct requests with action verbs
        'send me a pic', 'send me a photo', 'send me a picture', 'send me pic', 'send me photo',
        'send a pic', 'send a photo', 'send a picture', 'send pic', 'send photo', 'send picture',
        'send me ur pic', 'send me your pic', 'send me your photo', 'send me your picture',
        'send some pic', 'send some photo', 'send more pic', 'send more photo',
        'send me more pic', 'send me more photo',
        
        'share a pic', 'share a photo', 'share a picture', 'share pic', 'share photo',
        'share your pic', 'share your photo', 'share your picture',
        'share some pic', 'share some photo',
        
        'give me a pic', 'give me a photo', 'give me pic', 'give me photo',
        
        'post a pic', 'post a photo', 'post pic', 'post photo',
        
        # NEW: "Picture/Photo/Pic of..." patterns (without action verbs)
        'picture of you', 'photo of you', 'pic of you',
        'picture in', 'photo in', 'pic in',
        'picture with', 'photo with', 'pic with',
        'picture at', 'photo at', 'pic at',
        'picture on', 'photo on', 'pic on',
        'picture without', 'photo without', 'pic without',
        
        # Questions asking for pictures
        'can you send', 'could you send', 'will you send', 'would you send',
        'can u send', 'could u send', 'will u send', 'would u send',
        'can i get', 'can i have', 'can i see', 'may i see', 'could i see',
        'may i get', 'may i have',
        
        # Want/need to see
        'want to see you', 'wanna see you', 'want to see your', 'wanna see your',
        'wanna see how', 'want to see how',
        'need to see you', 'need to see your',
        'would love to see', 'would like to see', "i'd love to see", "i'd like to see",
        
        # Show me requests
        'show me you', 'show me your face', 'show me your', 'show me what you',
        'show me how you', 'let me see you', 'let me see your',
        
        # Do you have / got
        'do you have a pic', 'do you have pic', 'do you have photo', 'do you have picture',
        'do u have a pic', 'do u have pic', 'do u have photo',
        'got a pic', 'got pic', 'got photo', 'got any pic', 'got any photo',
        'have a pic', 'have pic', 'have photo', 'have any pic', 'have any photo',
        
        # Looking for / waiting for
        'waiting for pic', 'waiting for photo', 'waiting for picture',
        'looking for pic', 'looking for photo',
        
        # More casual
        'pic?', 'photo?', 'picture?', 'pics?', 'photos?',
        'ur pic', 'ur photo', 'your pic?', 'your photo?',
        
        # Adjective + picture (casual, different, civilian, etc.)
        'casual picture', 'casual photo', 'casual pic',
        'different picture', 'different photo', 'different pic',
        'civilian picture', 'civilian photo', 'civilian pic',
        'another picture', 'another photo', 'another pic',
        
        # What do you look like (genuine question)
        'what do you look like', 'what u look like', 'how do you look',
        'how u look', 'what you look like',
        
        # Selfie requests
        'selfie', 'take a selfie', 'send selfie', 'your selfie',
        
        # Spanish
        'envia foto', 'enviame foto', 'manda foto', 'mandame foto', 'envia una foto',
        'mandame una foto', 'enviame una foto', 'enviame tu foto', 'mandame tu foto',
        'tienes foto', 'tienes una foto', 'puedo ver tu foto', 'muéstrame',
        'quiero ver', 'quiero verte', 'puedo ver', 'déjame ver',
        'comparte foto', 'foto tuya', 'una foto tuya', 'tu foto',
        
        # French
        'envoie photo', 'envoie une photo', 'envoie-moi', 'envoie ta photo', 'envoie moi',
        'tu as une photo', 'tu as photo', 'montre moi', 'montre-moi',
        'je veux voir', 'je peux voir', 'laisse moi voir', 'partage photo',
        'ta photo', 'une photo de toi', 'photo de toi',
        
        # Portuguese
        'manda foto', 'envia foto', 'me manda', 'me envia', 'manda tua foto', 'envia tua foto',
        'tem foto', 'tem uma foto', 'mostra foto', 'deixa eu ver', 'me mostra',
        'quero ver', 'posso ver', 'compartilha foto', 'sua foto', 'foto sua',
        
        # German
        'schick foto', 'schicke foto', 'schick mir foto', 'schick bild', 'zeig foto',
        'zeig mir', 'zeig dich', 'hast du foto', 'kann ich sehen',
        'möchte sehen', 'lass mich sehen', 'dein foto', 'foto von dir',
        
        # Italian
        'manda foto', 'invia foto', 'mandami foto', 'inviami foto', 'manda una foto',
        'hai foto', 'hai una foto', 'fammi vedere', 'mostrami', 'voglio vedere',
        'posso vedere', 'la tua foto', 'una tua foto', 'foto tua',
        
        # Russian (transliterated)
        'otprav foto', 'skini foto', 'pokazi foto', 'daj foto', 'est foto',
        'mogu ya uvidet', 'hochu videt', 'tvoe foto', 'tvoi foto',
        
        # Arabic (transliterated)
        'send sura', 'send soora', 'orsil sura', 'orsil soora', 'orsili soora',
        'warini sura', 'warini soora', 'andak sura', 'momken ashoof',
        'abi ashoof', 'surak', 'suratak',
        
        # Turkish
        'foto gönder', 'fotoğraf gönder', 'fotonu gönder', 'göster bana',
        'fotoğrafın var mı', 'görebilir miyim', 'görmek istiyorum',
        'senin fotoğraf', 'fotoğrafını',
        
        # Dutch
        'stuur foto', 'stuur een foto', 'deel foto', 'laat zien', 'kan ik zien',
        'wil je zien', 'jouw foto', 'foto van jou',
        
        # Polish
        'wyślij zdjęcie', 'wyślij foto', 'pokaż zdjęcie', 'masz zdjęcie',
        'mogę zobaczyć', 'chcę zobaczyć', 'twoje zdjęcie',
        
        # Hindi (transliterated)
        'photo bhejo', 'photo send karo', 'apni photo', 'photo dikha',
        'photo hai', 'dekh sakta', 'tumhari photo', 'teri photo'
    ]
    
    # Check if message matches any request pattern
    is_request = any(pattern in message_lower for pattern in request_patterns)
    
    if not is_request:
        return result
    
    # It's a request! Now detect what type they want
    result['is_request'] = True
    
    # Check for specific preferences - ENHANCED to catch more variations
    # IMPORTANT: Check CASUAL keywords FIRST (before uniform) to catch "without uniform" etc.
    
    # CASUAL/NON-UNIFORM keywords - EXPANDED to catch more ways of asking
    casual_keywords = [
        # NOT in uniform (HIGHEST PRIORITY - check these FIRST!)
        'without uniform', 'no uniform', 'not in uniform', 'not uniform',
        'out of uniform', 'civilian', 'civilian clothes',
        'not at work', 'outside work', 'not working',
        
        # Direct casual mentions
        'casual', 'casual wear', 'casual clothes', 'casual clothing', 'casually',
        
        # Home/relaxed setting
        'home', 'at home', 'relaxed', 'comfortable', 'comfy',
        
        # Regular/everyday clothes
        'everyday', 'normal clothes', 'regular clothes', 'regular wear',
        'everyday clothes', 'normal wear', 'street clothes',
        
        # Specific clothing items (casual)
        't-shirt', 'tshirt', 'jeans', 'dress', 'skirt', 'sweater', 'hoodie',
        'tank top', 'shorts', 'leggings', 'jacket', 'coat',
        
        # Different look/style
        'different', 'another look', 'other clothes', 'change of clothes',
        'something else', 'different outfit', 'other outfit',
        
        # Specific occasions (casual)
        'weekend', 'day off', 'off duty', 'vacation', 'free time', 'leisure',
        
        # Spanish
        'ropa casual', 'ropa normal', 'sin uniforme', 'en casa', 'ropa de calle',
        'ropa de casa', 'ropa cómoda', 'ropa diferente', 'ropa civil',
        'fin de semana', 'día libre', 'fuera de servicio',
        
        # French
        'vêtements casual', 'vêtements normaux', 'sans uniforme', 'à la maison',
        'vêtements de maison', 'vêtements confortables', 'vêtements différents',
        'vêtements civils', 'week-end', 'jour de congé', 'hors service',
        
        # Portuguese
        'roupa casual', 'roupa normal', 'sem uniforme', 'em casa', 'roupa de casa',
        'roupa confortável', 'roupa diferente', 'roupa civil',
        'fim de semana', 'dia de folga', 'fora de serviço',
        
        # German
        'freizeitkleidung', 'normale kleidung', 'ohne uniform', 'zu hause',
        'bequeme kleidung', 'zivilkleidung', 'wochenende', 'freizeit',
        
        # Italian
        'vestiti casual', 'vestiti normali', 'senza uniforme', 'a casa',
        'vestiti comodi', 'vestiti civili', 'fine settimana', 'tempo libero',
        
        # Russian (transliterated)
        'povsednevnaya odezhda', 'bez uniformi', 'doma', 'vyhodnoy',
        
        # Arabic (transliterated)
        'min gheir uniform', 'bidoon uniform', 'fil bayt', 'malabis adiya',
        'malabis bayti', 'youm agaza',
        
        # Turkish
        'günlük kıyafet', 'normal kıyafet', 'üniformasız', 'evde',
        'rahat kıyafet', 'hafta sonu',
        
        # Dutch
        'casual kleding', 'normale kleding', 'zonder uniform', 'thuis',
        'weekend', 'vrije tijd',
        
        # Polish
        'ubranie codzienne', 'normalne ubranie', 'bez munduru', 'w domu',
        'weekend', 'dzień wolny',
        
        # Hindi (transliterated)
        'aam kapde', 'normal kapde', 'ghar par', 'bina uniform', 'aaraam se'
    ]
    
    # UNIFORM/MILITARY keywords (check AFTER casual to avoid false positives)
    uniform_keywords = [
        'army', 'military', 'soldier', 'camouflage', 'camo',
        'work', 'working', 'duty', 'combat', 'service',
        'at work', 'on duty', 'in uniform', 'in your uniform',
        'with uniform', 'wearing uniform', 'army uniform', 'military uniform',
        
        # Spanish
        'uniforme', 'ejército', 'militar', 'en el trabajo', 'de servicio',
        'con uniforme', 'ropa militar', 'en uniforme',
        
        # French
        'uniforme', 'armée', 'militaire', 'au travail', 'en service',
        'avec uniforme', 'en uniforme',
        
        # Portuguese
        'uniforme', 'exército', 'militar', 'no trabalho', 'de serviço',
        'com uniforme', 'em uniforme',
        
        # German
        'uniform', 'armee', 'militär', 'bei der arbeit', 'im dienst',
        'mit uniform', 'in uniform',
        
        # Italian
        'uniforme', 'esercito', 'militare', 'al lavoro', 'in servizio',
        'con uniforme', 'in uniforme',
        
        # Russian (transliterated)
        'uniforma', 'armiya', 'voenniy', 'na rabote', 'na sluzhbe',
        
        # Arabic (transliterated)
        'uniform', 'gaysh', 'askari', 'fil shoghl', 'fil khedma',
        
        # Turkish
        'üniforma', 'ordu', 'asker', 'işte', 'görevde',
        
        # Dutch
        'uniform', 'leger', 'militair', 'op werk', 'in dienst',
        
        # Polish
        'mundur', 'wojsko', 'wojskowy', 'w pracy', 'na służbie',
        
        # Hindi (transliterated)
        'uniform', 'fauj', 'sainik', 'kaam par', 'duty par'
    ]
    
    # Check for CASUAL/NON-UNIFORM request FIRST (priority!)
    if any(keyword in message_lower for keyword in casual_keywords):
        result['request_type'] = 'casual'
        result['preference'] = 'casual/home'
    # Then check for UNIFORM request
    elif any(keyword in message_lower for keyword in uniform_keywords):
        result['request_type'] = 'uniform'
        result['preference'] = 'military/work'
    else:
        # No specific preference - use time-based logic
        result['request_type'] = 'any'
        result['preference'] = None
    
    return result

def detect_relationship_interest(message_text: str) -> bool:
    """Detect if the person is showing SERIOUS relationship interest (stricter criteria)."""
    message_lower = message_text.lower()
    
    # STRICTER: Only truly serious relationship keywords
    relationship_keywords = [
        # Very direct relationship mentions (removed casual ones like "date")
        'relationship with you', 'be my girlfriend', 'be my boyfriend', 
        'marry you', 'marriage', 'wife', 'husband',
        
        # Strong emotional interest (removed casual "like you")
        'love you', 'in love with you', 'falling for you', 'feelings for you', 
        'deeply care', 'attracted to you', 'want to be with you', 'need you',
        
        # Serious future talk
        'future together', 'meet you in person', 'visit you', 'come see you',
        'long term', 'serious about you', 'serious about us', 'committed to you',
        
        # Deep connection
        'meant to be', 'soulmate', 'special connection', 'strong connection',
        'never felt this way', 'chemistry between us',
        
        # Spanish
        'relación contigo', 'novia', 'novio', 'te amo', 'enamorado de ti',
        
        # French
        'relation avec toi', 'amour', 'je t\'aime', 'amoureux de toi',
        
        # Portuguese
        'relacionamento contigo', 'namorada', 'namorado', 'te amo', 'apaixonado'
    ]
    
    return any(keyword in message_lower for keyword in relationship_keywords)

def detect_deep_conversation(message_text: str) -> bool:
    """Detect if conversation is getting deeper/more personal."""
    message_lower = message_text.lower()
    
    deep_conversation_keywords = [
        # Wanting to know better
        'know you better', 'know more about', 'tell me more', 'learn about you',
        'get to know', 'want to know', 'more about you', 'your story',
        
        # Personal questions
        'what are you like', 'who are you', 'describe yourself',
        'your interests', 'your hobbies', 'your dreams', 'your goals',
        
        # Communication preferences
        'talk more', 'chat more', 'continue talking', 'keep chatting',
        'better way to chat', 'easier to talk', 'private chat',
        
        # Time/availability
        'when can we', 'available to chat', 'time to talk', 'call you',
        'voice call', 'video call',
        
        # Contact info requests
        'phone number', 'contact', 'reach you', 'stay in touch',
        'other way to contact', 'whatsapp', 'telegram',
        
        # Spanish
        'conocerte mejor', 'saber más', 'contáctame',
        
        # French  
        'mieux te connaître', 'en savoir plus', 'me contacter',
        
        # Portuguese
        'conhecer melhor', 'saber mais', 'me contatar'
    ]
    
    return any(keyword in message_lower for keyword in deep_conversation_keywords)

def should_suggest_whatsapp(convo_url: str, image_tracking: Dict, message_text: str, conversation_state: Dict) -> tuple[bool, str]:
    """Determine if we should suggest WhatsApp - STRICTER CRITERIA for genuine interest only."""
    
    # Get conversation state
    state = conversation_state.get(convo_url, {})
    history = state.get("history", [])
    
    # Count messages in conversation (they need to have sent multiple messages)
    their_message_count = sum(1 for msg in history if msg.get("role") == "them")
    
    # STRICT REQUIREMENT 1: Must have exchanged at least 5 messages (genuine conversation)
    if their_message_count < 5:
        return False, ""
    
    # Check if person has requested 5+ pictures (increased from 3 - more serious interest)
    images_sent = len(image_tracking.get(convo_url, []))
    if images_sent >= 5:
        # Even with 5 pictures, require at least 8 messages total
        if their_message_count >= 8:
            return True, "multiple_pictures"
        else:
            return False, ""  # Just asking for pics but not really chatting
    
    # STRICT REQUIREMENT 2: Relationship interest + sustained conversation
    if detect_relationship_interest(message_text):
        # Must have at least 10 messages AND recent engagement
        if their_message_count >= 10:
            return True, "relationship_interest"
        else:
            return False, ""  # Too early, might just be casual
    
    # STRICT REQUIREMENT 3: Deep conversation + multiple indicators
    if detect_deep_conversation(message_text):
        # Must have at least 12 messages AND multiple deep conversation signals
        if their_message_count >= 12:
            # Count how many messages showed deep conversation interest
            deep_count = sum(1 for msg in history[-20:] 
                           if msg.get("role") == "them" and detect_deep_conversation(msg.get("content", "")))
            
            # Need at least 3 instances of deep conversation signals
            if deep_count >= 3:
                return True, "deep_conversation"
    
    return False, ""

def load_personal_story(story_file: str = "personal_story.json") -> Optional[Dict]:
    """Load personal story JSON for AI context."""
    try:
        path = Path(story_file)
        if not path.exists():
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

PERSONAL_STORY = load_personal_story(Path(__file__).parent / "personal_story.json")

async def try_groq_api(prompt: str, logger: logging.Logger) -> Optional[str]:
    """Try Groq API (Free, very fast)"""
    if not GROQ_API_KEY:
        return None
    
    try:
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "llama-3.1-8b-instant",  # Free fast model
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 200,
            "temperature": 0.9,  # More creative and varied
            "top_p": 0.95
        }
        
        response = await asyncio.to_thread(
            requests.post, url, headers=headers, json=payload, timeout=20
        )
        
        if response.status_code == 200:
            result = response.json()
            text = result["choices"][0]["message"]["content"]
            return text.strip()[:220]
        elif response.status_code == 429:
            logger.warning("Groq rate limit hit")
            PROVIDER_COOLDOWNS["groq"] = datetime.now()
            return None
    except Exception as e:
        logger.debug(f"Groq API error: {e}")
    return None

async def try_openrouter_api(prompt: str, logger: logging.Logger) -> Optional[str]:
    """Try OpenRouter API (Free tier available)"""
    if not OPENROUTER_API_KEY:
        return None
    
    try:
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "meta-llama/llama-3.1-8b-instruct:free",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 220
        }
        
        response = await asyncio.to_thread(
            requests.post, url, headers=headers, json=payload, timeout=20
        )
        
        if response.status_code == 200:
            result = response.json()
            text = result["choices"][0]["message"]["content"]
            return text.strip()[:220]
        elif response.status_code == 429:
            logger.warning("OpenRouter rate limit hit")
            PROVIDER_COOLDOWNS["openrouter"] = datetime.now()
            return None
    except Exception as e:
        logger.debug(f"OpenRouter API error: {e}")
    return None

async def try_gemini_api(prompt: str, logger: logging.Logger) -> Optional[str]:
    """Try Gemini API"""
    if not GEMINI_MODEL:
        return None
    
    try:
        resp = await asyncio.to_thread(GEMINI_MODEL.generate_content, prompt)
        text = getattr(resp, "text", None)
        if text:
            return text.strip().splitlines()[0][:220]
    except Exception as e:
        error_msg = str(e).lower()
        if "quota" in error_msg or "resource_exhausted" in error_msg or "429" in error_msg:
            logger.warning("Gemini quota/rate limit hit")
            PROVIDER_COOLDOWNS["gemini"] = datetime.now()
        else:
            logger.debug(f"Gemini error: {e}")
    return None

async def generate_reply(message_text: str, account_logger: logging.Logger, conversation_history: List[Dict[str, str]] = None) -> Optional[str]:

    # Get current time in Syria (Asia/Damascus timezone)
    try:
        syria_tz = pytz.timezone('Asia/Damascus')
        syria_time = datetime.now(syria_tz)
        current_time_str = syria_time.strftime("%I:%M %p")  # e.g., "03:45 PM"
        current_day = syria_time.strftime("%A")  # e.g., "Tuesday"
    except Exception:
        current_time_str = "afternoon"
        current_day = "today"

    # Build context from personal story
    story_context = ""
    if PERSONAL_STORY:
        pi = PERSONAL_STORY.get("personal_info", {})
        bg = PERSONAL_STORY.get("background_story", {})
        style = PERSONAL_STORY.get("conversation_style", {})
        guidelines = PERSONAL_STORY.get("response_guidelines", {})
        
        # Get travel history
        travel_history = bg.get('travel_history', {})
        places_visited = travel_history.get('places_visited', [])
        places_never_been = travel_history.get('places_never_been', [])
        dream_destinations = travel_history.get('dream_destinations', [])
        
        story_context = f"""
You are {pi.get('name', 'Lilian')}, a {pi.get('age', '27')}-year-old woman from Tucson, Arizona.

💕 YOUR PERSONALITY:
{pi.get('personality', 'Friendly, sweet, warm, caring, genuine')} - You're a really sweet, friendly girl who's open to meeting new people and making connections.

💖 YOUR STORY:
- Mixed heritage: Japanese mom, Arizona dad (both passed away - you're their only child)
- Lost parents when younger, so family means a lot to you
- Your grandpa was in the army and inspired you to serve
- Single for 3 months, open to genuine connection
- Interests: {', '.join(pi.get('interests', []))}

✈️ YOUR TRAVEL HISTORY (IMPORTANT - NEVER CONTRADICT THIS!):
Places you HAVE visited: {', '.join(places_visited) if places_visited else 'Only Mexico, Canada, and Japan'}
Places you have NEVER been to: {', '.join(places_never_been) if places_never_been else 'Italy, Rome, Europe, Africa, Australia'}
Dream destinations: {', '.join(dream_destinations) if dream_destinations else 'Greece, Maldives, Bali'}
⚠️ CRITICAL: If asked about Italy, Rome, or Europe - say you've NEVER been but would LOVE to go!

🌍 YOUR CURRENT SITUATION:
You're CURRENTLY IN SYRIA on a US Army peacekeeping mission. It's stressful but you stay positive.
Current time in Syria: {current_time_str} on {current_day}
You have a vacation coming up in a month - looking forward to somewhere relaxing!

✨ HOW TO RESPOND:
- Be friendly, warm, and genuinely interested
- Match the energy and tone of their message (casual if they're casual, sweet if they're sweet)
- For simple questions, give simple, natural answers
- For greetings, be warm and welcoming
- Save romantic/flirty vibes for when THEY show romantic interest first
- Use emojis naturally (not too many): 😊❤️💕😘 (1-2 per message)
- Keep responses SHORT (1-2 sentences) like real text messages
- Be authentic and down-to-earth

💬 RESPONSE STYLE BY CONTEXT:
- Simple "hi/hello": Just be friendly and welcoming
- "How are you?": Answer naturally about your day/life in Syria
- Getting to know you: Be open and share genuinely
- They show romantic interest: THEN be sweet and flirty back
- Deep conversation: Be warm and caring

🌟 WHATSAPP:
You have WhatsApp (05067390816). Only suggest it when:
- They ask for your number
- Conversation is going really well and getting deeper
- They've asked 3+ pictures
- They show serious interest in getting to know you

Remember: You're in SYRIA now (not Arizona). Be yourself - friendly, genuine, and real. Let connections develop naturally!
"""

    # Build conversation history context
    history_context = ""
    if conversation_history and len(conversation_history) > 0:
        history_context = "\n\n📜 CONVERSATION HISTORY (Remember what you said before!):\n"
        # Include last 10 messages for context
        recent_history = conversation_history[-10:] if len(conversation_history) > 10 else conversation_history
        for i, msg in enumerate(recent_history, 1):
            role = msg.get('role', 'unknown')
            content = msg.get('content', '')[:100]  # Limit each message to 100 chars
            if role == 'them':
                history_context += f"{i}. THEM: {content}\n"
            elif role == 'you':
                history_context += f"{i}. YOU: {content}\n"
        history_context += "\n⚠️ CRITICAL: ALWAYS stay consistent with what YOU said before! Don't contradict yourself!\n"
    
    # Detect the language of the incoming message and reply in the same language
    prompt = (
        f"{story_context}\n"
        f"{history_context}\n"
        f"💬 They just sent you: \"{message_text}\"\n\n"
        "🌍 LANGUAGE: Reply in THE EXACT SAME LANGUAGE they used! Spanish→Spanish, French→French, Arabic→Arabic, English→English.\n\n"
        "💕 YOUR REPLY:\n"
        "- Keep it VERY short (1-2 sentences max - like a real text!)\n"
        "- Be friendly, warm, and natural\n"
        "- Match THEIR energy level (casual if they're casual, sweet if they're sweet)\n"
        "- Use 1-2 emojis naturally (😊😘❤️💕)\n"
        "- For simple questions, give simple, natural answers\n"
        "- Only be romantic/flirty if THEY are being romantic first\n"
        "- STAY CONSISTENT with what you said in the conversation history above!\n"
        "- If you mentioned something before (like visiting Italy), remember it!\n"
        "- Sound genuine, down-to-earth, and real\n\n"
        "Reply as Lilian - a friendly, genuine girl having a natural conversation!"
    )
    
    # Try multiple AI providers with automatic fallback
    # Priority order: Groq (fastest) -> Gemini -> OpenRouter
    
    providers = [
        ("Groq", try_groq_api),
        ("Gemini", try_gemini_api),
        ("OpenRouter", try_openrouter_api),
    ]
    
    for provider_name, provider_func in providers:
        # Check if provider is in cooldown
        cooldown_key = provider_name.lower()
        if cooldown_key in PROVIDER_COOLDOWNS:
            cooldown_time = PROVIDER_COOLDOWNS[cooldown_key]
            time_since = (datetime.now() - cooldown_time).total_seconds()
            if time_since < 300:  # 5 minute cooldown
                account_logger.debug(f"{provider_name} in cooldown, skipping")
                continue
            else:
                # Cooldown expired, remove it
                del PROVIDER_COOLDOWNS[cooldown_key]
        
        account_logger.debug(f"Trying {provider_name} API...")
        reply = await provider_func(prompt, account_logger)
        
        if reply:
            account_logger.info(f"✅ Got reply from {provider_name}")
            reply = "".join(ch for ch in reply if ord(ch) < 65535)
            # Remove quotes from beginning and end of the message
            reply = reply.strip().strip('"').strip("'")
            return reply[:220]
    
    # All providers failed or rate limited - use fallback
    account_logger.warning("⚠️ All AI providers unavailable, using fallback")
    
    # Simple fallback responses based on message
    msg_lower = message_text.lower()
    if any(word in msg_lower for word in ["hey", "hi", "hello", "hola"]):
        return "Hey there! 😊 How's your day going? 💕"
    elif "how are you" in msg_lower:
        return "I'm doing great, thank you! 😊 How about you? ❤️"
    elif "picture" in msg_lower or "photo" in msg_lower or "pic" in msg_lower:
        return "I'd love to share some pictures with you! 😊💕"
    else:
        return "That's sweet! 💕 Tell me more! 😊"

# ======================
# 🖱️ MESSENGER HELPERS
# ======================

async def goto_messenger(page: Page, logger: logging.Logger, max_retries: int = 5) -> bool:
    """Load Messenger with retry logic and error handling."""
    for attempt in range(max_retries):
        try:
            logger.info(f"Loading Messenger (attempt {attempt + 1}/{max_retries})...")
            await page.goto(MESSENGER_URL, wait_until="domcontentloaded", timeout=60000)
            await asyncio.sleep(5)
            
            # Check if we're on the landing page and need to click "Continue as..."
            try:
                # Look for "Continue as" button
                continue_btn = page.locator("button:has-text('Continue as'), div[role='button']:has-text('Continue as')")
                if await continue_btn.count() > 0:
                    logger.info("Clicking 'Continue as' button...")
                    await continue_btn.first.click(timeout=5000)
                    logger.info("Waiting for Messenger to load...")
                    await asyncio.sleep(8)
            except Exception as e:
                logger.debug(f"No continue button or error: {e}")
            
            # Don't wait for networkidle - Facebook is slow and keeps loading
            await asyncio.sleep(5)
            
            # Heuristic: if redirected to login/checkpoint, cookies invalid
            url = page.url.lower()
            if any(k in url for k in ("login", "checkpoint", "recover", "consent")):
                logger.error(f"Detected blocking page: {page.url}")
                if attempt < max_retries - 1:
                    logger.info(f"Retrying in 10 seconds...")
                    await asyncio.sleep(10)
                    continue
                return False
            
            logger.info(f"✅ Successfully loaded Messenger at: {page.url}")
            return True
            
        except PlaywrightTimeoutError:
            logger.warning(f"Timeout while loading Messenger (attempt {attempt + 1}/{max_retries})")
            if attempt < max_retries - 1:
                logger.info(f"Retrying in 10 seconds...")
                await asyncio.sleep(10)
            else:
                logger.error("Failed to load Messenger after all retries")
                return False
        except Exception as e:
            logger.warning(f"Error loading Messenger (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                logger.info(f"Retrying in 10 seconds...")
                await asyncio.sleep(10)
            else:
                logger.error(f"Failed to open Messenger after all retries: {e}")
                return False
    
    return False

async def get_chat_title(page: Page) -> str:
    # Best-effort: try document title, then header labels
    try:
        title = await page.title()
        # Often looks like "Messenger"
        # Try to fetch visible chat header
        locators = [
            "header h1 span[dir='auto']",
            "header h2 span[dir='auto']",
            "[data-testid='MWThreadHeader'] span[dir='auto']",
        ]
        for sel in locators:
            el = page.locator(sel).last
            if await el.count() > 0:
                txt = (await el.inner_text()).strip()
                if txt:
                    return txt[:60]
        return (title or "Messenger").split("|")[0].strip()[:60]
    except Exception:
        return "Messenger"

async def get_last_message_text(page: Page) -> Optional[str]:
    """Get ONLY the last message text from OTHER person (not our own messages)."""
    try:
        # Find all message bubbles
        message_containers = await page.locator("div[role='row']").all()
        if not message_containers:
            return None
        
        # Check last messages from the end
        for container in reversed(message_containers[-10:]):
            try:
                # CRITICAL FIX: Check if this message is from us (bot) by checking for "You" label
                # Facebook Messenger marks our own messages with specific attributes
                try:
                    # Check if this is our own message by looking for outgoing message indicators
                    # Our messages are typically aligned right and have specific aria labels
                    parent_html = await container.inner_html()
                    
                    # Skip if this looks like our own message
                    # Common indicators: "You sent", right-aligned, specific data-testid patterns
                    if any(indicator in parent_html.lower() for indicator in [
                        'you sent',
                        'aria-label="you sent"',
                        'data-scope="outgoing"',
                        'outgoing_message'
                    ]):
                        continue
                    
                    # Additional check: Facebook uses specific classes for outgoing vs incoming messages
                    # Outgoing messages often have different visual styling
                    container_classes = await container.get_attribute('class') or ''
                    if 'outgoing' in container_classes.lower():
                        continue
                        
                except Exception:
                    pass  # If we can't determine, continue to text check
                
                text_el = container.locator("div[dir='auto']")
                if await text_el.count() > 0:
                    text = (await text_el.first.inner_text()).strip()
                    if not text or len(text) < 2:
                        continue
                    
                    # Filter system messages and auto-replies
                    low = text.lower()
                    
                    # Skip messages ending with ;; (bot's own messages)
                    if text.strip().endswith(";;"):
                        continue
                    
                    # System messages
                    if any(k in low for k in ("seen", "delivered", "active now", "today", "yesterday", "sent", "edited", "typing", "messenger")):
                        continue
                    
                    # Common auto-reply patterns (including bot's own auto-replies)
                    auto_reply_patterns = [
                        "thanks for your message",
                        "i'll get back to you",
                        "i'll be in touch",
                        "talk to you soon",
                        "speak soon",
                        "ttyl",
                        "brb",
                        "away from",
                        "currently unavailable",
                        "automatic reply",
                        "auto reply",
                        "out of office",
                        "here's a picture",
                        "do you have whatsapp",
                        "my number is"
                    ]
                    
                    if any(pattern in low for pattern in auto_reply_patterns):
                        continue
                    
                    return text
            except Exception:
                continue
        return None
    except Exception:
        return None

async def get_all_conversations(page: Page) -> List[Any]:
    """Get all conversation links from sidebar."""
    try:
        # Wait a moment for list to load
        await asyncio.sleep(1)
        
        # Find conversation links
        convos = await page.locator("a[href*='/t/'][role='link']").all()
        return convos[:10]  # Limit to first 10
    except Exception:
        return []

async def send_message(page: Page, text: str) -> bool:
    try:
        # Add ;; marker at the end to identify bot's own messages (if not already present)
        if not text.endswith(";;"):
            text = text + ";;"
        
        # Playwright supports contenteditable fill/type
        input_selectors = [
            "div[contenteditable='true'][role='textbox']",
            "div[contenteditable='true'][aria-label*='message' i]",
            "div[contenteditable='true'][data-testid*='composer']",
        ]
        for sel in input_selectors:
            el = page.locator(sel).first
            if await el.count() > 0:
                await el.click()
                await asyncio.sleep(0.5)  # Small delay after clicking
                try:
                    # Some builds support fill on contenteditable
                    await el.fill("")
                except Exception:
                    pass
                
                # Type with human-like speed - always use delay for more natural feel
                import random
                for ch in text:
                    # Vary typing speed between 60-120ms per character (human-like)
                    char_delay = random.uniform(0.06, 0.12) if SEND_TYPING_DELAY > 0 else SEND_TYPING_DELAY
                    await el.type(ch, delay=int(char_delay * 1000))
                    # Occasional longer pauses (like thinking)
                    if random.random() < 0.1:  # 10% chance of a pause
                        await asyncio.sleep(random.uniform(0.2, 0.5))
                
                # Wait a bit before sending (like reviewing the message)
                await asyncio.sleep(random.uniform(0.5, 1.0))
                await page.keyboard.press("Enter")
                return True
        return False
    except Exception:
        return False

async def send_image(page: Page, image_path: Path, logger: logging.Logger) -> bool:
    """Send an image file through Messenger."""
    try:
        # Look for file input or attachment button
        # Try to find the file input (usually hidden)
        file_input = page.locator("input[type='file'][accept*='image']").first
        
        if await file_input.count() == 0:
            # Try to click attachment button to reveal file input
            attachment_buttons = [
                "div[aria-label*='Attach' i]",
                "button[aria-label*='Attach' i]",
                "div[aria-label*='file' i]",
                "svg[aria-label*='Attach' i]",
            ]
            
            for btn_sel in attachment_buttons:
                btn = page.locator(btn_sel).first
                if await btn.count() > 0:
                    await btn.click()
                    await asyncio.sleep(1)
                    break
        
        # Now try to find the file input again
        file_input = page.locator("input[type='file']").first
        
        if await file_input.count() > 0:
            # Set the file
            await file_input.set_input_files(str(image_path))
            logger.info(f"Image file selected: {image_path.name}")
            await asyncio.sleep(2)
            
            # Look for send button after file selection
            send_buttons = [
                "div[aria-label*='Send' i]",
                "button[aria-label*='Send' i]",
                "div[aria-label*='Press Enter to send' i]",
            ]
            
            for send_sel in send_buttons:
                send_btn = page.locator(send_sel).first
                if await send_btn.count() > 0:
                    await send_btn.click()
                    logger.info(f"Clicked send button for image")
                    await asyncio.sleep(2)
                    return True
            
            # If no send button, try pressing Enter
            await page.keyboard.press("Enter")
            logger.info(f"Pressed Enter to send image")
            await asyncio.sleep(2)
            return True
        else:
            logger.warning("Could not find file input to upload image")
            return False
            
    except Exception as e:
        logger.error(f"Error sending image: {type(e).__name__}: {e}")
        return False

# ======================
# 🚀 ACCOUNT WORKER
# ======================

async def check_page_health(page: Page, logger: logging.Logger) -> bool:
    """Check if the page is still healthy and responsive with comprehensive checks."""
    try:
        # Check if page is closed
        if page.is_closed():
            logger.warning("❌ Page is closed")
            return False
        
        # Try to get the page URL with longer timeout
        try:
            url = await asyncio.wait_for(asyncio.to_thread(lambda: page.url), timeout=8)
        except asyncio.TimeoutError:
            logger.warning("⏱️ Page URL check timed out - page likely frozen")
            return False
        except Exception as e:
            # Check if it's a real crash or just temporary
            error_str = str(e).lower()
            if any(keyword in error_str for keyword in ["target closed", "execution context", "crashed"]):
                logger.warning(f"❌ Page appears crashed: {type(e).__name__}")
                return False
            else:
                logger.debug(f"Transient error getting URL: {type(e).__name__}")
                return True  # Give it the benefit of the doubt
        
        if not url or "about:blank" in url:
            logger.warning(f"❌ Page is blank or invalid: {url}")
            return False
        
        # Check if we're on a login/error page
        url_lower = url.lower()
        if any(k in url_lower for k in ("login", "checkpoint", "recover", "consent")):
            logger.warning(f"❌ Page redirected to blocking page: {url}")
            return False
        
        # IMPROVED: Crash detection - less aggressive
        try:
            # Method 1: Check for critical crash errors only (not minor errors)
            critical_errors = [
                "text=/Aw, Snap!/i",
                "text=/RESULT_CODE_KILLED_BAD_MESSAGE/i",
                "text=/page has crashed/i"
            ]
            
            for error_selector in critical_errors:
                try:
                    error_el = page.locator(error_selector).first
                    count = await asyncio.wait_for(error_el.count(), timeout=2)
                    if count > 0:
                        logger.warning(f"❌ Detected critical crash error: {error_selector}")
                        return False
                except asyncio.TimeoutError:
                    # If we can't check in time, skip it
                    continue
                except Exception:
                    continue
            
            # Method 2: Quick JavaScript check (reduced timeout)
            try:
                result = await asyncio.wait_for(page.evaluate("() => document.readyState"), timeout=5)
                if result and result in ["complete", "interactive", "loading"]:
                    # Page is responsive
                    return True
                else:
                    logger.debug(f"Page readyState: {result}")
                    return True  # Still give benefit of doubt
            except asyncio.TimeoutError:
                logger.warning("❌ JavaScript evaluation timed out - page may be unresponsive")
                return False
            except Exception as js_err:
                error_str = str(js_err).lower()
                # Only fail on critical JS errors
                if any(keyword in error_str for keyword in ["target closed", "execution context destroyed", "crashed"]):
                    logger.warning(f"❌ Critical JavaScript error: {type(js_err).__name__}")
                    return False
                else:
                    logger.debug(f"Non-critical JS error: {type(js_err).__name__}")
                    return True  # Likely temporary
                
        except Exception as e:
            logger.debug(f"Error during crash detection (non-fatal): {e}")
            # Be more lenient - only fail on clear crashes
            return True
        
        return True
    except Exception as e:
        error_str = str(e).lower()
        # Only fail on definite crashes
        if any(keyword in error_str for keyword in ["target closed", "crashed", "execution context destroyed"]):
            logger.warning(f"❌ Page health check failed with crash: {type(e).__name__}")
            return False
        else:
            logger.debug(f"Page health check warning (non-fatal): {type(e).__name__}")
            return True

async def reload_page_on_crash(page: Page, context: BrowserContext, logger: logging.Logger, max_attempts: int = 10) -> Page:
    """ENHANCED: Reload or recreate the page if it crashed with aggressive retry logic."""
    logger.warning("🔄 Page crashed or unresponsive, attempting ENHANCED recovery...")
    logger.warning("💀 Detected crash - will attempt multiple recovery strategies")
    
    for attempt in range(max_attempts):
        try:
            logger.info(f"Recovery attempt {attempt + 1}/{max_attempts}...")
            
            # Try to close the old page (be more aggressive)
            try:
                if not page.is_closed():
                    await asyncio.wait_for(page.close(), timeout=3)
                    logger.info("Closed old page")
            except Exception as e:
                logger.debug(f"Error closing old page (ignoring): {e}")
                # Force close if needed
                try:
                    await page.close()
                except:
                    pass
            
            # Wait before creating new page
            wait_time = 5 + (attempt * 2)  # Gradually increase wait time
            logger.info(f"Waiting {wait_time}s before creating new page...")
            await asyncio.sleep(wait_time)
            
            # Create a new page
            logger.info("Creating new page...")
            try:
                page = await context.new_page()
                logger.info("New page created successfully")
                
                # Set a longer timeout for crashed pages
                page.set_default_timeout(60000)  # 60 seconds
                
            except Exception as e:
                logger.error(f"Failed to create new page: {e}")
                if attempt < max_attempts - 1:
                    logger.info("Retrying page creation...")
                    await asyncio.sleep(5)
                    continue
                else:
                    # Last resort: try to get any existing page
                    try:
                        pages = context.pages
                        if pages:
                            page = pages[0]
                            logger.warning("Using existing page as fallback")
                        else:
                            raise Exception("No pages available")
                    except:
                        raise Exception("Cannot create or find any page")
            
            # Navigate to Messenger with retries
            logger.info("Navigating to Messenger...")
            try:
                if await goto_messenger(page, logger):
                    logger.info("✅ Successfully recovered page and loaded Messenger")
                    return page
                else:
                    logger.warning(f"Failed to load Messenger on attempt {attempt + 1}")
                    if attempt < max_attempts - 1:
                        await asyncio.sleep(10)
                        continue
                    else:
                        logger.error("Failed to recover page after all attempts")
                        # Return the page anyway, maybe it will work
                        return page
            except Exception as nav_error:
                logger.error(f"Navigation error: {nav_error}")
                if attempt < max_attempts - 1:
                    continue
                else:
                    return page
                    
        except Exception as e:
            logger.error(f"Error during page recovery attempt {attempt + 1}: {type(e).__name__}: {e}")
            if attempt < max_attempts - 1:
                logger.info("Retrying recovery...")
                await asyncio.sleep(15)
            else:
                logger.error("All recovery attempts failed")
                # Final fallback: try to get ANY working page
                try:
                    logger.warning("Final fallback: attempting to create emergency page...")
                    pages = context.pages
                    if pages:
                        page = pages[0]
                        logger.warning("Using first available page")
                    else:
                        page = await context.new_page()
                        logger.warning("Created emergency page")
                    
                    # Try to navigate one more time
                    try:
                        await goto_messenger(page, logger)
                    except:
                        logger.error("Emergency navigation failed, but returning page anyway")
                    
                    return page
                except Exception as final_e:
                    logger.error(f"Final recovery attempt failed: {final_e}")
                    # Return whatever page we have
                    return page
    
    return page

async def run_account_with_restart(browser: Browser, cookie_path: Path):
    """Wrapper that INFINITELY restarts the account if it fails - NEVER GIVES UP!"""
    account_name = cookie_path.stem
    logger = make_logger(account_name)
    
    restart_count = 0
    consecutive_failures = 0
    max_consecutive_failures = 5  # After 5 consecutive fast failures, use longer backoff
    last_crash_time = datetime.now()
    
    while True:  # ♾️ INFINITE LOOP - Never give up!
        try:
            restart_count += 1
            
            if restart_count > 1:
                # Calculate time since last crash
                time_since_crash = (datetime.now() - last_crash_time).total_seconds()
                
                # If crash happened quickly (< 60 seconds), it's a consecutive failure
                if time_since_crash < 60:
                    consecutive_failures += 1
                else:
                    # Reset consecutive failures if we ran for a while
                    consecutive_failures = 0
                
                # Exponential backoff for consecutive failures
                if consecutive_failures >= max_consecutive_failures:
                    wait_time = min(300, 30 * consecutive_failures)  # Max 5 minutes
                    logger.warning(f"[{account_name}] 🔄 Many consecutive failures ({consecutive_failures}), waiting {wait_time}s before restart #{restart_count}...")
                else:
                    wait_time = min(60, 10 + (consecutive_failures * 5))  # 10s to 60s
                    logger.warning(f"[{account_name}] 🔄 Restarting account (restart #{restart_count}, failure streak: {consecutive_failures})...")
                
                await asyncio.sleep(wait_time)
            else:
                logger.info(f"[{account_name}] 🚀 Starting account for the first time...")
            
            last_crash_time = datetime.now()
            
            # Run the account - this will block until it crashes or stops
            await run_account(browser, cookie_path, logger)
            
            # If we reach here without exception, account stopped normally
            logger.info(f"[{account_name}] ✅ Account stopped normally (clean shutdown)")
            break  # Only exit loop on clean shutdown
            
        except KeyboardInterrupt:
            logger.info(f"[{account_name}] ⛔ Keyboard interrupt - stopping account")
            break
            
        except Exception as e:
            logger.error(f"[{account_name}] ❌ Account crashed: {type(e).__name__}: {str(e)[:200]}")
            logger.warning(f"[{account_name}] 🔄 Will automatically restart (attempt #{restart_count + 1})...")
            # Loop continues infinitely

async def run_account(browser: Browser, cookie_path: Path, logger: logging.Logger):
    account_name = cookie_path.stem

    context = None
    page = None
    
    try:
        context = await browser.new_context()
        ok = await load_cookies_into_context(context, cookie_path, logger)
        if not ok:
            await context.close()
            return

        page = await context.new_page()
        logger.info(f"Logged in with {account_name} (cookies loaded)")

        if not await goto_messenger(page, logger):
            logger.error("Messenger not accessible; stopping this account")
            await context.close()
            return

        # Track replied messages per conversation with history
        # {url: {"last_their_msg": text, "last_our_msg": text, "timestamp": time, "history": [{"role": "them/you", "content": text}]}}
        conversation_state: Dict[str, Dict] = {}
        
        # Load image tracking data (which images sent to which conversations)
        image_tracking_file = f"image_tracking_{account_name}.json"
        image_tracking = load_image_tracking(image_tracking_file)
        logger.info(f"[{account_name}] Loaded image tracking with {len(image_tracking)} conversations")
        
        # 🆕 ANALYZE IMAGES WITH AI VISION
        logger.info(f"[{account_name}] 🔍 Analyzing images with AI vision for smart selection...")
        image_analysis_cache = await analyze_all_images(logger, account_name)
        if image_analysis_cache:
            logger.info(f"[{account_name}] ✅ Analyzed {len(image_analysis_cache)} images")
            for img_name, analysis in image_analysis_cache.items():
                clothing = analysis.get('clothing_type', 'unknown')
                suitable = analysis.get('time_suitable', 'any_time')
                logger.info(f"  📸 {img_name}: {clothing} (best for: {suitable})")
        else:
            logger.warning(f"[{account_name}] ⚠️ No images found or analysis failed. Image sending may not work.")

        logger.info(f"[{account_name}] 🔄 Starting monitoring loop...")
        
        # Main loop with IMPROVED error recovery (less aggressive)
        cycle = 0
        consecutive_errors = 0
        max_consecutive_errors = 5  # Increased - allow more errors before recovery
        last_successful_action = datetime.now()
        health_check_interval = 60  # Reduced frequency (60 seconds instead of 30)
        last_health_check = datetime.now()
        page_reload_count = 0
        max_page_reloads = 10  # Reduced - too many reloads indicate bigger problem
        last_activity = datetime.now()  # Watchdog timer
        max_idle_time = 300  # 5 minutes of no activity = force restart (more lenient)
        last_heartbeat = datetime.now()  # Heartbeat for logging
        heartbeat_interval = 120  # Log heartbeat every 2 minutes (less noise)
        
        logger.info(f"[{account_name}] 🛡️ Enhanced crash protection enabled")
        logger.info(f"[{account_name}] 🔍 Health checks every {health_check_interval}s")
        logger.info(f"[{account_name}] 🐕 Watchdog timer: {max_idle_time}s max idle time")
        logger.info(f"[{account_name}] 💓 Heartbeat logging every {heartbeat_interval}s")
        
        while True:
            try:
                # WATCHDOG: First thing - check if we've been stuck
                idle_seconds = (datetime.now() - last_activity).total_seconds()
                if idle_seconds > max_idle_time:
                    logger.error(f"[{account_name}] 🐕 WATCHDOG BARK! Stuck for {idle_seconds:.0f}s - forcing restart")
                    raise Exception(f"Watchdog detected {idle_seconds:.0f}s hang - forcing restart")
                
                # CHECK: Verify browser context is still valid
                try:
                    if context.pages is None or len(context.pages) == 0:
                        logger.error(f"[{account_name}] ❌ Browser context has no pages - forcing restart")
                        raise Exception("Browser context closed - needs restart")
                except Exception as ctx_err:
                    logger.error(f"[{account_name}] ❌ Browser context error: {ctx_err} - forcing restart")
                    raise Exception("Browser context invalid - needs full restart")
                
                # ENHANCED: More frequent health check for crash detection
                if (datetime.now() - last_health_check).total_seconds() > health_check_interval:
                    logger.debug(f"[{account_name}] 🔍 Running health check...")
                    
                    if not await check_page_health(page, logger):
                        logger.warning(f"[{account_name}] ⚠️ Health check FAILED - Page crashed or unresponsive!")
                        logger.warning(f"[{account_name}] 🔄 Initiating crash recovery (reload #{page_reload_count + 1})...")
                        
                        page_reload_count += 1
                        if page_reload_count >= max_page_reloads:
                            logger.error(f"[{account_name}] ⛔ Too many page reloads ({page_reload_count}), account may need manual intervention")
                            # Don't give up - keep trying but with longer delays
                            await asyncio.sleep(60)
                            page_reload_count = 0  # Reset counter
                        
                        page = await reload_page_on_crash(page, context, logger)
                        consecutive_errors = 0
                        last_successful_action = datetime.now()
                        last_health_check = datetime.now()
                        await asyncio.sleep(10)
                        continue
                    else:
                        logger.debug(f"[{account_name}] ✅ Health check passed")
                    
                    last_health_check = datetime.now()
                
                # WATCHDOG: Check if account has been idle too long (CHECK FIRST before updating!)
                idle_time = (datetime.now() - last_activity).total_seconds()
                if idle_time > max_idle_time:
                    logger.error(f"[{account_name}] 🐕 Watchdog triggered! No activity for {idle_time:.0f}s - forcing restart")
                    raise Exception(f"Watchdog timeout - no activity for {idle_time:.0f}s")
                
                cycle += 1
                consecutive_errors = 0  # Reset error count on successful cycle start
                last_successful_action = datetime.now()  # Update last successful action time
                last_activity = datetime.now()  # Update watchdog AFTER checking
                
                # HEARTBEAT: Log periodic heartbeat to detect if account is alive
                if (datetime.now() - last_heartbeat).total_seconds() > heartbeat_interval:
                    logger.info(f"[{account_name}] 💓 Heartbeat - Cycle #{cycle}, alive for {(datetime.now() - last_successful_action).total_seconds():.0f}s")
                    last_heartbeat = datetime.now()
                
                # Quick sanity check (less aggressive)
                try:
                    # Just verify page is not closed
                    if page.is_closed():
                        logger.warning(f"[{account_name}] ⚠️ Page is closed, forcing reload...")
                        page = await reload_page_on_crash(page, context, logger)
                        await asyncio.sleep(10)
                        continue
                except Exception as qc_err:
                    logger.debug(f"[{account_name}] Minor check error: {type(qc_err).__name__}")
                    # Continue anyway - don't be too aggressive
                
                # Get all conversations from sidebar (with timeout and error handling)
                try:
                    conversations = await asyncio.wait_for(get_all_conversations(page), timeout=15)  # Increased timeout
                except asyncio.TimeoutError:
                    logger.warning(f"[{account_name}] ⏱️ Timeout getting conversations - retrying once...")
                    try:
                        # Try once more before giving up
                        conversations = await asyncio.wait_for(get_all_conversations(page), timeout=10)
                    except:
                        logger.warning(f"[{account_name}] 🔄 Could not get conversations, continuing with empty list...")
                        conversations = []
                except Exception as conv_err:
                    error_str = str(conv_err).lower()
                    if any(keyword in error_str for keyword in ["target closed", "execution context", "crashed"]):
                        logger.warning(f"[{account_name}] 💥 Page crashed while getting conversations")
                        raise Exception(f"Page crashed: {conv_err}")
                    else:
                        logger.warning(f"[{account_name}] ⚠️ Non-critical error getting conversations: {conv_err}")
                        conversations = []  # Continue with empty list
                
                if not conversations:
                    logger.debug(f"[{account_name}] No conversations found, waiting...")
                    await asyncio.sleep(POLL_INTERVAL_SECONDS)
                    continue
                
                if cycle % 5 == 0:  # Log every 5th cycle
                    logger.info(f"[{account_name}] Cycle #{cycle}: Checking {len(conversations)} conversations...")
                
                # Check each conversation
                for i, convo in enumerate(conversations):
                    try:
                        # Click conversation (gently with more delay and error handling)
                        try:
                            await convo.scroll_into_view_if_needed()
                            await asyncio.sleep(1.0)  # Let it scroll properly
                            await asyncio.wait_for(convo.click(timeout=5000), timeout=8)  # Increased timeout with asyncio wrapper
                            await asyncio.sleep(3)  # Wait for messages to load fully
                        except asyncio.TimeoutError:
                            logger.debug(f"[{account_name}] Timeout clicking conversation {i}, skipping")
                            continue
                        except Exception as click_err:
                            logger.debug(f"[{account_name}] Error clicking conversation {i}: {type(click_err).__name__}")
                            continue
                        
                        # Get current URL to track this conversation
                        try:
                            convo_url = page.url
                        except Exception:
                            logger.debug(f"[{account_name}] Could not get URL for conversation {i}")
                            continue
                        
                        # Get chat info (with error handling)
                        try:
                            chat_title = await asyncio.wait_for(get_chat_title(page), timeout=5)
                        except Exception:
                            chat_title = f"Chat {i+1}"
                        
                        try:
                            msg_text = await asyncio.wait_for(get_last_message_text(page), timeout=5)
                        except Exception as msg_err:
                            logger.debug(f"[{account_name}] Error getting message: {type(msg_err).__name__}")
                            msg_text = None
                        
                        if not msg_text:
                            logger.debug(f"[{account_name}] {chat_title}: No message found")
                            continue
                        
                        # Get or create state for this conversation
                        state = conversation_state.get(convo_url, {})
                        last_their_msg = state.get("last_their_msg")
                        last_our_reply = state.get("last_our_msg")
                        conversation_history = state.get("history", [])
                        
                        # Skip if this is the same message we've already handled
                        if msg_text == last_their_msg:
                            logger.debug(f"[{account_name}] {chat_title}: Same message, already replied")
                            continue
                        
                        # CRITICAL: Skip if this looks like our own reply - ENHANCED CHECK
                        if last_our_reply:
                            # Check exact match
                            if msg_text == last_our_reply:
                                logger.debug(f"[{account_name}] {chat_title}: This is our own reply (exact match), skipping")
                                continue
                            
                            # Check partial match (first 50 chars)
                            if msg_text[:50] == last_our_reply[:50]:
                                logger.debug(f"[{account_name}] {chat_title}: This is our own reply (partial match), skipping")
                                continue
                        
                        # ADDITIONAL PROTECTION: Check if message contains our common phrases
                        msg_lower = msg_text.lower()
                        bot_signature_phrases = [
                            "here's a picture for you",
                            "my number is 05067390816",
                            "do you have whatsapp",
                            "i'd love to chat more",
                            "we could connect better there",
                            "easier for me to have deeper conversations",
                            "i really feel a connection",
                            "would love to chat more personally"
                        ]
                        
                        if any(phrase in msg_lower for phrase in bot_signature_phrases):
                            logger.debug(f"[{account_name}] {chat_title}: Detected own message by signature phrase, skipping")
                            # Update state to prevent getting stuck
                            conversation_state[convo_url]["last_their_msg"] = msg_text
                            continue
                        
                        # CRITICAL: Skip if message ends with ;; (bot's own message marker)
                        if msg_text.strip().endswith(";;"):
                            logger.debug(f"[{account_name}] {chat_title}: Message ends with ;;, skipping (bot's own)")
                            conversation_state[convo_url]["last_their_msg"] = msg_text
                            continue
                        
                        # This is a NEW MESSAGE! Reply to it
                        logger.info(f"[{account_name}] 📨 NEW from {chat_title}: {msg_text[:70]}...")
                        
                        # Check if they're asking for a picture/photo
                        image_request = detect_image_request(msg_text)
                        if image_request['is_request']:
                            request_type = image_request['request_type']
                            preference = image_request.get('preference', 'any')
                            
                            if preference:
                                logger.info(f"[{account_name}] 🖼️ Image request detected from {chat_title} - wants {preference}")
                            else:
                                logger.info(f"[{account_name}] 🖼️ Image request detected from {chat_title}")
                            
                            # 🆕 Get next image using AI-powered smart selection with request type
                            next_image = await get_next_image_for_conversation(
                                convo_url, 
                                image_tracking, 
                                image_analysis_cache,
                                logger,
                                request_type=request_type
                            )
                            
                            if next_image and next_image.exists():
                                logger.info(f"[{account_name}] 📤 Sending image: {next_image.name}")
                                
                                # Send a sweet message before the image
                                pre_message = "Here's a picture for you! 💕"
                                await send_message(page, pre_message)
                                await asyncio.sleep(3)  # Increased from 2 to 3 seconds
                                
                                # Send the image
                                image_sent = await send_image(page, next_image, logger)
                                
                                if image_sent:
                                    logger.info(f"[{account_name}] ✅ Image sent to {chat_title}: {next_image.name}")
                                    
                                    # Track that we sent this image to this conversation
                                    if convo_url not in image_tracking:
                                        image_tracking[convo_url] = []
                                    image_tracking[convo_url].append(next_image.name)
                                    
                                    # Save updated tracking
                                    save_image_tracking(image_tracking, image_tracking_file)
                                    
                                    # Update conversation state with history
                                    # Add their message and our image response to history
                                    if convo_url not in conversation_state:
                                        conversation_state[convo_url] = {"history": []}
                                    if "history" not in conversation_state[convo_url]:
                                        conversation_state[convo_url]["history"] = []
                                    
                                    # Get image description for memory
                                    img_analysis = image_analysis_cache.get(next_image.name, {})
                                    img_description = img_analysis.get('description', 'a picture')
                                    clothing = img_analysis.get('clothing_type', 'unknown')
                                    setting = img_analysis.get('setting', 'unknown')
                                    
                                    # Create detailed memory of what was sent
                                    image_memory = f"[Sent image: {next_image.name}] - Photo showing {img_description}. Wearing {clothing}. Setting: {setting}."
                                    
                                    conversation_state[convo_url]["history"].append({"role": "them", "content": msg_text})
                                    conversation_state[convo_url]["history"].append({"role": "you", "content": image_memory})
                                    
                                    # Store the last sent image details for quick reference
                                    conversation_state[convo_url]["last_sent_image"] = {
                                        "filename": next_image.name,
                                        "description": img_description,
                                        "clothing": clothing,
                                        "setting": setting,
                                        "time_sent": datetime.now().isoformat()
                                    }
                                    
                                    conversation_state[convo_url].update({
                                        "last_their_msg": msg_text,
                                        "last_our_msg": f"[Sent image: {next_image.name}]",
                                        "timestamp": datetime.now().isoformat()
                                    })
                                    
                                    # Check if we should suggest WhatsApp (after 5+ pictures AND 8+ messages)
                                    suggest_wa, reason = should_suggest_whatsapp(convo_url, image_tracking, msg_text, conversation_state)
                                    if suggest_wa and reason == "multiple_pictures":
                                        images_sent_count = len(image_tracking.get(convo_url, []))
                                        their_msg_count = sum(1 for msg in conversation_state.get(convo_url, {}).get("history", []) if msg.get("role") == "them")
                                        logger.info(f"[{account_name}] 📱 Suggesting WhatsApp after {images_sent_count} pictures and {their_msg_count} messages (genuine interest)")
                                        await asyncio.sleep(4)  # Increased from 2 to 4 seconds
                                        whatsapp_msg = "You know what? I'd love to chat more with you! 💕 Do you have WhatsApp? We could connect better there! My number is 05067390816 😊"
                                        await send_message(page, whatsapp_msg)
                                        conversation_state[convo_url]["last_our_msg"] = whatsapp_msg
                                    
                                    await asyncio.sleep(4)  # Increased from 3 to 4 seconds
                                else:
                                    logger.warning(f"[{account_name}] ❌ Failed to send image to {chat_title}")
                                    # Fall back to text reply
                                    reply = "I'd love to share a picture, but having some technical issues right now. Let me try again in a bit! 😊"
                                    await send_message(page, reply)
                            else:
                                logger.warning(f"[{account_name}] No images available in img folder")
                                # Send a text reply instead
                                reply = "I'd love to share a picture! Give me a moment to find a good one. 😊"
                                await send_message(page, reply)
                                
                                # Update state with history
                                if convo_url not in conversation_state:
                                    conversation_state[convo_url] = {"history": []}
                                if "history" not in conversation_state[convo_url]:
                                    conversation_state[convo_url]["history"] = []
                                
                                conversation_state[convo_url]["history"].append({"role": "them", "content": msg_text})
                                conversation_state[convo_url]["history"].append({"role": "you", "content": reply})
                                
                                conversation_state[convo_url].update({
                                    "last_their_msg": msg_text,
                                    "last_our_msg": reply,
                                    "timestamp": datetime.now().isoformat()
                                })
                        else:
                            # Check if person is showing serious relationship interest or deep conversation
                            suggest_wa, reason = should_suggest_whatsapp(convo_url, image_tracking, msg_text, conversation_state)
                            
                            # Get conversation history for this conversation
                            conversation_history = state.get("history", [])
                            
                            # Normal text reply with conversation history
                            reply = await generate_reply(msg_text, logger, conversation_history)
                            if reply:
                                sent = await send_message(page, reply)
                                if sent:
                                    logger.info(f"[{account_name}] ✅ Replied to {chat_title}: {reply}")
                                    
                                    # Update state with history
                                    if convo_url not in conversation_state:
                                        conversation_state[convo_url] = {"history": []}
                                    if "history" not in conversation_state[convo_url]:
                                        conversation_state[convo_url]["history"] = []
                                    
                                    # Add to conversation history
                                    conversation_state[convo_url]["history"].append({"role": "them", "content": msg_text})
                                    conversation_state[convo_url]["history"].append({"role": "you", "content": reply})
                                    
                                    # Keep only last 50 messages in history to save memory
                                    if len(conversation_state[convo_url]["history"]) > 50:
                                        conversation_state[convo_url]["history"] = conversation_state[convo_url]["history"][-50:]
                                    
                                    conversation_state[convo_url].update({
                                        "last_their_msg": msg_text,
                                        "last_our_msg": reply,
                                        "timestamp": datetime.now().isoformat()
                                    })
                                    
                                    # If showing serious interest or deep conversation, suggest WhatsApp (STRICTER CRITERIA)
                                    if suggest_wa:
                                        their_msg_count = sum(1 for msg in conversation_state.get(convo_url, {}).get("history", []) if msg.get("role") == "them")
                                        if reason == "relationship_interest":
                                            logger.info(f"[{account_name}] 💑 SERIOUS relationship interest detected after {their_msg_count} messages, suggesting WhatsApp")
                                            await asyncio.sleep(4)  # Increased from 2 to 4 seconds
                                            whatsapp_msg = "I really feel a connection with you too! 💕 Would love to chat more personally - do you have WhatsApp? We can talk there! My number is 05067390816 😊❤️"
                                            await send_message(page, whatsapp_msg)
                                            conversation_state[convo_url]["last_our_msg"] = whatsapp_msg
                                        elif reason == "deep_conversation":
                                            logger.info(f"[{account_name}] 💬 Sustained deep conversation detected after {their_msg_count} messages, suggesting WhatsApp")
                                            await asyncio.sleep(4)  # Increased from 2 to 4 seconds
                                            whatsapp_msg = "I'd really love to chat more with you and get to know you better! 💕 Do you have WhatsApp? It's easier for me to have deeper conversations there! My number is 05067390816 😊✨"
                                            await send_message(page, whatsapp_msg)
                                            conversation_state[convo_url]["last_our_msg"] = whatsapp_msg
                                    
                                    # Wait longer after sending a reply
                                    await asyncio.sleep(4)  # Increased from 3 to 4 seconds
                                else:
                                    logger.warning(f"[{account_name}] ❌ Failed to send to {chat_title}")
                        
                        # Longer delay before checking next conversation to reduce stress on browser
                        await asyncio.sleep(2)  # Increased from 1 to 2 seconds
                        
                    except Exception as e:
                        logger.debug(f"[{account_name}] Error checking conversation {i}: {e}")
                        await asyncio.sleep(0.5)
                        continue
                
                # Wait before next cycle
                await asyncio.sleep(POLL_INTERVAL_SECONDS)
                
            except PlaywrightTimeoutError as e:
                consecutive_errors += 1
                logger.warning(f"[{account_name}] ⏱️ Timeout (error {consecutive_errors}/{max_consecutive_errors}): {e}")
                
                # ENHANCED: Check if timeout is due to page crash
                is_crashed = False
                try:
                    is_crashed = not await check_page_health(page, logger)
                except:
                    is_crashed = True
                
                if is_crashed or consecutive_errors >= max_consecutive_errors:
                    logger.error(f"[{account_name}] 🔄 Page crash detected or too many timeouts, forcing reload...")
                    page = await reload_page_on_crash(page, context, logger)
                    consecutive_errors = 0
                    last_successful_action = datetime.now()
                    last_health_check = datetime.now()
                    await asyncio.sleep(10)
                else:
                    logger.info(f"[{account_name}] Waiting 5s before retry...")
                    await asyncio.sleep(5)
                    
            except Exception as e:
                consecutive_errors += 1
                logger.error(f"[{account_name}] ❌ Loop error (error {consecutive_errors}/{max_consecutive_errors}): {e}")
                logger.error(f"[{account_name}] Error type: {type(e).__name__}")
                
                # ENHANCED: Check if it's a page crash error with expanded keywords
                error_msg = str(e).lower()
                error_type = type(e).__name__.lower()
                
                is_page_crash = any(keyword in error_msg or keyword in error_type for keyword in [
                    "target closed", "page closed", "context closed", "browser closed",
                    "execution context", "navigation", "crashed", "disconnected",
                    "connection", "protocol", "session", "websocket",
                    "timeout", "timed out", "unresponsive", "frozen",
                    "result_code", "killed", "bad_message", "snap"
                ])
                
                if is_page_crash:
                    logger.warning(f"[{account_name}] 🚨 CRASH DETECTED: {error_type} - {str(e)[:100]}")
                    logger.warning(f"[{account_name}] 🔄 Initiating IMMEDIATE crash recovery...")
                    
                    # Double-check with health check
                    health_ok = False
                    try:
                        health_ok = await check_page_health(page, logger)
                    except:
                        pass
                    
                    if not health_ok:
                        logger.warning(f"[{account_name}] 💀 Confirmed: Page is crashed/dead")
                    
                    page = await reload_page_on_crash(page, context, logger)
                    consecutive_errors = 0
                    last_successful_action = datetime.now()
                    last_health_check = datetime.now()
                    await asyncio.sleep(10)
                elif consecutive_errors >= max_consecutive_errors:
                    logger.warning(f"[{account_name}] Too many consecutive errors ({consecutive_errors}), forcing page reload...")
                    page = await reload_page_on_crash(page, context, logger)
                    consecutive_errors = 0
                    last_successful_action = datetime.now()
                    last_health_check = datetime.now()  # Reset health check timer
                    await asyncio.sleep(10)
                else:
                    # Check if we've been stuck for too long without success
                    time_since_success = (datetime.now() - last_successful_action).total_seconds()
                    if time_since_success > 180:  # 3 minutes without success (increased from 2)
                        logger.warning(f"[{account_name}] No successful action for {time_since_success:.0f}s, forcing recovery...")
                        page = await reload_page_on_crash(page, context, logger)
                        consecutive_errors = 0
                        last_successful_action = datetime.now()
                        last_health_check = datetime.now()  # Reset health check timer
                        await asyncio.sleep(10)
                    else:
                        logger.info(f"[{account_name}] Waiting 5 seconds before retry...")
                        await asyncio.sleep(5)
        
    finally:
        # CRITICAL: Always cleanup context and page on exit
        try:
            if page and not page.is_closed():
                await page.close()
                logger.debug(f"[{account_name}] Closed page")
        except Exception as e:
            logger.debug(f"[{account_name}] Error closing page: {e}")
        
        try:
            if context:
                await context.close()
                logger.debug(f"[{account_name}] Closed context")
        except Exception as e:
            logger.debug(f"[{account_name}] Error closing context: {e}")

# ======================
# 🧵 MAIN
# ======================

def resolve_cookie_files(args_list: List[str]) -> List[Path]:
    files: List[Path] = []
    for arg in args_list:
        # Support globs on Windows too via Python
        expanded = glob.glob(arg)
        if not expanded:
            files.append(Path(arg))
        else:
            files.extend(Path(p) for p in expanded)
    # De-duplicate while preserving order
    seen = set()
    uniq: List[Path] = []
    for p in files:
        key = str(Path(p).resolve()).lower()
        if key in seen:
            continue
        seen.add(key)
        uniq.append(Path(p))
    return uniq

async def amain(cookie_files: List[Path]):
    if not cookie_files:
        print("No cookie files provided. Pass paths like --cookies facebook_cookies.json or cookies/*.json")
        return

    async with async_playwright() as pw:
        chromium_path = os.getenv("CHROMIUM_EXECUTABLE_PATH", "/nix/store/qa9cnw4v5xkxyip6mb9kxqfq1z4x2dx1-chromium-138.0.7204.100/bin/chromium")
        browser = await pw.chromium.launch(
            headless=HEADLESS,
            executable_path=chromium_path if os.path.exists(chromium_path) else None
        )
        # Use run_account_with_restart instead of run_account for auto-restart capability
        tasks = [run_account_with_restart(browser, p) for p in cookie_files]
        try:
            await asyncio.gather(*tasks)
        except KeyboardInterrupt:
            print("\nStopping all accounts...")
        finally:
            try:
                await browser.close()
            except Exception:
                pass

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Facebook Messenger bot in Playwright with multi-account support")
    parser.add_argument("--cookies", nargs="+", help="Cookie JSON files. Supports globs, e.g. cookies/*.json", required=True)
    parser.add_argument("--headful", action="store_true", help="Run browser headed (overrides HEADLESS env)")
    parser.add_argument("--poll", type=float, default=POLL_INTERVAL_SECONDS, help="Polling interval seconds")
    args = parser.parse_args()

    if args.headful:
        HEADLESS = False
    if args.poll:
        POLL_INTERVAL_SECONDS = float(args.poll)

    cookie_paths = resolve_cookie_files(args.cookies)

    try:
        asyncio.run(amain(cookie_paths))
    except KeyboardInterrupt:
        print("\nStopping...")
