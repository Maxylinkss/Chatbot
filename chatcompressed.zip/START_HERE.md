# 🚀 Facebook Messenger Bot - Quick Start

## ✨ Your Folder is Now Clean and Organized!

All old/unused files have been moved to: `C:\Users\Administrator\Desktop\notuseful\`

---

## 📁 What's in This Folder

### 🎯 Main Files (What You Need)

**To Manage Service:**
- **`SERVICE_MANAGER.bat`** ⭐ - Main menu (use this!)
- `RESTART_SERVICE.bat` - Restart after API/code changes
- `UPDATE_SERVICE_WITH_NEW_COOKIES.bat` - Update when adding accounts
- `CHECK_SERVICE_STATUS.bat` - Check if bot is running
- `VIEW_LIVE_LOGS.bat` - Watch bot activity

**Bot Files:**
- `messenger_playwright_multi.py` - The bot code
- `.env` - Your API keys and settings
- `requirements.txt` - Python dependencies

**Cookie Files:**
- `facebook_cookies.json` - Account 1
- `facebook_cookies_account4.json` - Account 2
- `facebook_cookies_account5.json` - Account 3
- `facebook_cookies_account6.json` - Account 4

**Documentation:**
- `SIMPLE_GUIDE.md` ⭐ - Start here for instructions
- `QUICK_REFERENCE.md` - Quick command reference
- `SERVICE_README.md` - Complete service guide
- `HOW_TO_UPDATE_SERVICE.md` - How to make changes
- `SERVICE_vs_BATCH_COMPARISON.md` - Service vs batch files
- `SETUP_COMPLETE.md` - Setup summary

---

## 🎮 How to Use

### 1. To Manage Your Bot
**Double-click: `SERVICE_MANAGER.bat`**

You'll see a menu:
```
1. Restart Service (after changing API/code)
2. Update Service with New Cookie Files
3. Check Service Status
4. View Live Logs
5. Stop Service
6. Start Service
7. Exit
```

### 2. After Changing API Keys
1. Edit `.env` file
2. Double-click `RESTART_SERVICE.bat`
3. Done!

### 3. After Adding New Account
1. Add new cookie file (e.g., `facebook_cookies_account7.json`)
2. Double-click `UPDATE_SERVICE_WITH_NEW_COOKIES.bat`
3. Done!

---

## 📖 Documentation

Read these in order:

1. **`SIMPLE_GUIDE.md`** - Easy step-by-step guide (no confusion!)
2. **`QUICK_REFERENCE.md`** - Quick answers for common tasks
3. **`SERVICE_README.md`** - Complete documentation

---

## ✅ What Was Cleaned Up

**Moved 57 files to Desktop/notuseful:**
- 10 old BAT files (FORCE_RESTART_HIDDEN.bat, etc.)
- 34 old documentation files
- 6 old test scripts
- 2 ZIP files
- 5 old TXT files

**Why?** They were replaced by the new service management system!

---

## 🎯 Remember

**Two simple commands:**
1. Changed API/code? → `RESTART_SERVICE.bat`
2. Added account? → `UPDATE_SERVICE_WITH_NEW_COOKIES.bat`

**Or just use:** `SERVICE_MANAGER.bat` for everything!

---

## 🔧 Service Info

- **Service Name:** FacebookMessengerBot
- **Status:** Running 24/7
- **Auto-start:** Enabled (starts on boot)
- **Keeps running:** Even when you log off

---

## 📍 Support Files

**Folders:**
- `logs/` - Bot activity logs
- `img/` - Images for sending
- `nssm-2.24/` - Service manager tool

**Cache Files:**
- `image_tracking_*.json` - Image sending history
- `image_analysis_cache_*.json` - AI analysis cache
- `personal_story.json` - Bot personality

---

## 🎉 You're All Set!

Your bot is running as a Windows service. You can:
- ✅ Log off - bot keeps running
- ✅ Restart Windows - bot auto-starts
- ✅ Change API keys - just restart service
- ✅ Add accounts - just run update script

**Everything is simple now!** 🚀
