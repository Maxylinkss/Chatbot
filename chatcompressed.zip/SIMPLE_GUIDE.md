# 🎯 SIMPLE GUIDE - No Confusion!

## ✨ The Easy Way: Just Double-Click BAT Files!

I created simple batch files for you. Just **double-click** them!

---

## 📁 Main File to Use

### **`SERVICE_MANAGER.bat`** ⭐ START HERE!

Double-click this file and you'll see a menu:

```
========================================
FACEBOOK BOT SERVICE MANAGER
========================================

1. Restart Service (after changing API/code)
2. Update Service with New Cookie Files
3. Check Service Status
4. View Live Logs
5. Stop Service
6. Start Service
7. Exit
========================================
```

Just type the number you want!

---

## 🔄 What to Use When

### **Scenario 1: I Changed My API Keys**

1. Edit your `.env` file (change the API key)
2. Double-click: **`RESTART_SERVICE.bat`**
3. Done! ✅

**OR** use `SERVICE_MANAGER.bat` → Choose option 1

---

### **Scenario 2: I Updated My Bot Code**

1. Edit your `messenger_playwright_multi.py` file
2. Double-click: **`RESTART_SERVICE.bat`**
3. Done! ✅

**OR** use `SERVICE_MANAGER.bat` → Choose option 1

---

### **Scenario 3: I Added a New Cookie File (New Account)**

1. Add your new cookie file (e.g., `facebook_cookies_account7.json`)
2. Double-click: **`UPDATE_SERVICE_WITH_NEW_COOKIES.bat`**
3. Type `yes` when asked
4. Done! ✅

**OR** use `SERVICE_MANAGER.bat` → Choose option 2

---

### **Scenario 4: I Want to Check if Bot is Running**

Double-click: **`CHECK_SERVICE_STATUS.bat`**

**OR** use `SERVICE_MANAGER.bat` → Choose option 3

---

### **Scenario 5: I Want to See What the Bot is Doing**

Double-click: **`VIEW_LIVE_LOGS.bat`**

**OR** use `SERVICE_MANAGER.bat` → Choose option 4

---

## 📋 All BAT Files at a Glance

| File | When to Use |
|------|-------------|
| **SERVICE_MANAGER.bat** | Main menu - use this for everything! |
| **RESTART_SERVICE.bat** | After changing API keys, code, or cookie contents |
| **UPDATE_SERVICE_WITH_NEW_COOKIES.bat** | After adding/removing cookie files |
| **CHECK_SERVICE_STATUS.bat** | Check if bot is running |
| **VIEW_LIVE_LOGS.bat** | Watch bot activity in real-time |

---

## 🎬 Step-by-Step Example

### Example: Changing Your Gemini API Key

**Step 1:** Open `.env` file
```
Double-click: .env
```

**Step 2:** Change the API key
```
GEMINI_API_KEY=your_new_key_here
```

**Step 3:** Save and close the file

**Step 4:** Restart the service
```
Double-click: RESTART_SERVICE.bat
Press any key when asked
Wait for "SUCCESS! Service is running!"
```

**That's it!** Your new API key is now active! ✅

---

## 🍪 Example: Adding a 5th Account

**Step 1:** Get your new cookie file
```
Export cookies → Save as: facebook_cookies_account7.json
```

**Step 2:** Put it in the realchatapp folder
```
Copy facebook_cookies_account7.json to:
C:\Users\Administrator\Downloads\realchatapp\
```

**Step 3:** Update the service
```
Double-click: UPDATE_SERVICE_WITH_NEW_COOKIES.bat
Wait for it to detect all cookies
Type: yes
Wait for "SUCCESS! Service updated and running!"
```

**That's it!** Your bot now runs with 5 accounts! ✅

---

## ❓ Common Questions

### Q: After I restart, will my bot run like you set it up?
**A:** YES! The service is configured to run exactly like `FORCE_RESTART_HIDDEN.bat`:
- All your cookie files
- --poll 10
- HEADLESS=true
- Auto-restart on crash

### Q: Do I need to run PowerShell commands?
**A:** NO! Just double-click the BAT files. That's it!

### Q: What if I want to use my old FORCE_RESTART_HIDDEN.bat?
**A:** You can! Just stop the service first:
```
Double-click: SERVICE_MANAGER.bat → Choose option 5 (Stop Service)
Then run your FORCE_RESTART_HIDDEN.bat
```

### Q: How do I know if it's working?
**A:** 
```
Double-click: CHECK_SERVICE_STATUS.bat
```
If it says "RUNNING - All good!" then it's working! ✅

---

## 🎯 The Golden Rule

**Just remember these 2 files:**

1. **For normal changes (API, code):**
   - Double-click: `RESTART_SERVICE.bat`

2. **For adding/removing cookie files:**
   - Double-click: `UPDATE_SERVICE_WITH_NEW_COOKIES.bat`

**That's it!** No confusion! 🎉

---

## 🚀 TL;DR (Too Long, Didn't Read)

1. Changed something? → Double-click `RESTART_SERVICE.bat`
2. Added new account? → Double-click `UPDATE_SERVICE_WITH_NEW_COOKIES.bat`
3. Want menu? → Double-click `SERVICE_MANAGER.bat`

**Done!** 😊
