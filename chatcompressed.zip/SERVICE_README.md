# Facebook Messenger Bot - Windows Service Setup

## ✅ Service Successfully Installed!

Your Facebook Messenger Bot is now running as a **Windows Service** called `FacebookMessengerBot`.

**🔥 IMPORTANT:** This service runs the **SAME configuration** as your `FORCE_RESTART_HIDDEN.bat` file:
- Same cookie files (all 4 accounts)
- Same polling interval (--poll 10)
- Same headless mode (HEADLESS=true)
- Same auto-restart delay (15 seconds)

This means your bot will:
- ✅ Run automatically when Windows starts
- ✅ Continue running even after you log off
- ✅ Restart automatically if it crashes (15 second delay)
- ✅ Run in the background 24/7 with all latest features

---

## 🎮 Quick Commands

### Using PowerShell Management Script
```powershell
.\manage_service.ps1
```
This will open an interactive menu where you can:
- Start/Stop/Restart the service
- Check service status
- View logs in real-time

### Using PowerShell Commands Directly

**Check Service Status:**
```powershell
Get-Service -Name FacebookMessengerBot
```

**Start Service:**
```powershell
Start-Service -Name FacebookMessengerBot
```

**Stop Service:**
```powershell
Stop-Service -Name FacebookMessengerBot
```

**Restart Service:**
```powershell
Restart-Service -Name FacebookMessengerBot
```

### Using NSSM Commands

**Check Status:**
```powershell
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe status FacebookMessengerBot
```

**Start Service:**
```powershell
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe start FacebookMessengerBot
```

**Stop Service:**
```powershell
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe stop FacebookMessengerBot
```

**Restart Service:**
```powershell
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe restart FacebookMessengerBot
```

---

## 📋 View Logs

**Output Log (General Info):**
```powershell
Get-Content C:\Users\Administrator\Downloads\realchatapp\logs\service_output.log -Tail 50
```

**Error Log (Bot Activity & Errors):**
```powershell
Get-Content C:\Users\Administrator\Downloads\realchatapp\logs\service_error.log -Tail 50
```

**Live Logs (Watch in Real-Time):**
```powershell
Get-Content C:\Users\Administrator\Downloads\realchatapp\logs\service_error.log -Wait -Tail 20
```

---

## ⚙️ Service Configuration

| Setting | Value |
|---------|-------|
| **Service Name** | FacebookMessengerBot |
| **Start Type** | Automatic (starts on boot) |
| **Working Directory** | C:\Users\Administrator\Downloads\realchatapp |
| **Python Path** | C:\Users\Administrator\AppData\Local\Programs\Python\Python312\python.exe |
| **Script** | messenger_playwright_multi.py |
| **Arguments** | --cookies facebook_cookies.json facebook_cookies_account4.json facebook_cookies_account5.json facebook_cookies_account6.json --poll 10 |
| **Environment** | HEADLESS=true, PLAYWRIGHT_BROWSERS_PATH=C:\Users\Administrator\AppData\Local\ms-playwright |
| **Auto-Restart Delay** | 15 seconds (matches FORCE_RESTART_HIDDEN.bat) |
| **Output Log** | logs\service_output.log |
| **Error Log** | logs\service_error.log |

---

## 🔧 Troubleshooting

### Bot not responding?
1. Check if the service is running:
   ```powershell
   Get-Service -Name FacebookMessengerBot
   ```

2. Check the logs for errors:
   ```powershell
   Get-Content C:\Users\Administrator\Downloads\realchatapp\logs\service_error.log -Tail 50
   ```

3. Restart the service:
   ```powershell
   Restart-Service -Name FacebookMessengerBot
   ```

### Service won't start?
Check the event log for detailed error information:
```powershell
Get-EventLog -LogName Application -Source nssm -Newest 10
```

### Need to update cookie files?
1. Stop the service
2. Update your cookie JSON files
3. Start the service again

```powershell
Stop-Service -Name FacebookMessengerBot
# Update your cookie files here
Start-Service -Name FacebookMessengerBot
```

---

## 🗑️ Remove Service

If you ever need to remove the service:

```powershell
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe stop FacebookMessengerBot
C:\Users\Administrator\Downloads\realchatapp\nssm-2.24\win64\nssm.exe remove FacebookMessengerBot confirm
```

Or use the management script and select option 8.

---

## 📊 Windows Services Manager

You can also manage the service through Windows Services Manager:
1. Press `Win + R`
2. Type `services.msc`
3. Find "FacebookMessengerBot"
4. Right-click for options

---

## 🎉 Your bot is now running 24/7!

You can safely log off from your VPS and the bot will continue working in the background.
